import { DOCUMENT } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { AuthService, RoutingService } from '@spartacus/core';
import { HamburgerMenuService } from '@spartacus/storefront';
import { Observable } from 'rxjs';

declare let gigya: any;
let isCommerceLoggedIn: boolean;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles: [''],
})
export class AppComponent {
  isExpanded$: Observable<boolean> = this.hamburgerMenuService.isExpanded;
  constructor(authService: AuthService, private routingService: RoutingService, private hamburgerMenuService: HamburgerMenuService) {
    authService.isUserLoggedIn().subscribe((data) => {
      isCommerceLoggedIn = data;
    });
  }
  ngOnInit() {
    if (typeof gigya === 'undefined') {
      console.error('Gigya is not loaded!');
    } else {
      gigya?.accounts.getAccountInfo({
        callback: (res: any) => {
          const isCdcLoggedIn = res && res.status && res.status.toLowerCase() === 'ok';
          console.log('isCdcLoggedIn', isCdcLoggedIn, 'isCommerceLoggedIn', isCommerceLoggedIn);
          if (isCdcLoggedIn && !isCommerceLoggedIn) {
            this.routingService.go({ cxRoute: 'login' });
          } else if (!isCdcLoggedIn && isCommerceLoggedIn) {
            this.routingService.go({ cxRoute: 'logout' });
          }
        },
      });
    }
    this.isExpanded$.subscribe((data) => {
      if (data) {
        document.body.style.overflow = 'hidden';
      } else {
        document.body.style.overflow = 'auto';
      }
    });
  }
}
