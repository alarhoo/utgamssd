import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule, BrowserTransferStateModule } from '@angular/platform-browser';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AppComponent } from './app.component';
import { SpartacusModule } from './spartacus/spartacus.module';
import { DteSpartacusModule } from './spartacus/dte-spartacus.module';
import { AppRoutingModule } from '@spartacus/storefront';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    HttpClientModule,
    AppRoutingModule,
    StoreModule.forRoot({}),
    EffectsModule.forRoot([]),
    SpartacusModule,
    DteSpartacusModule,
    BrowserTransferStateModule,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
