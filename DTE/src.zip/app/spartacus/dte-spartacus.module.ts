import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { translations, translationChunksConfig } from '@spartacus/assets';
import { provideConfig, CmsConfig, I18nConfig, FeaturesConfig, ConfigModule, UrlModule } from '@spartacus/core';
import { AppRoutingModule, SearchBoxComponentService } from '@spartacus/storefront';
import { organizationTranslations, organizationTranslationChunksConfig } from '@spartacus/organization/administration/assets';
import { orderApprovalTranslations, orderApprovalTranslationChunksConfig } from '@spartacus/organization/order-approval/assets';
import { tmaTranslations, TmaB2bSpartacusModule } from '@spartacus/tua-spa';
import { DteLayoutModule } from './features/custom/configuration/layout/layout.module';
import { DteRoutingModule } from './features/custom/configuration/routing/routing.module';
import { DteSearchBoxComponentService } from './features/custom/services/dte-search-box-component.service';

@NgModule({
  declarations: [],
  imports: [
    AppRoutingModule,
    UrlModule,
    RouterModule,
    ConfigModule.withConfig({
      i18n: {
        resources: tmaTranslations,
      },
    }),
    // TmaB2bSpartacusModule,
    DteLayoutModule,
    DteRoutingModule,
  ],
  providers: [
    provideConfig(<CmsConfig>{
      featureModules: {
        organizationAdministration: {
          module: () => import('@spartacus/organization/administration').then((m) => m.AdministrationModule),
        },
      },
    }),
    provideConfig({
      i18n: {
        resources: organizationTranslations,
        chunks: organizationTranslationChunksConfig,
      },
    }),
    provideConfig(<CmsConfig>{
      featureModules: {
        organizationOrderApproval: {
          module: () => import('@spartacus/organization/order-approval').then((m) => m.OrderApprovalModule),
        },
      },
    }),
    provideConfig({
      i18n: {
        resources: orderApprovalTranslations,
        chunks: orderApprovalTranslationChunksConfig,
      },
    }),
    provideConfig(<I18nConfig>{
      // we bring in static translations to be up and running soon right away
      i18n: {
        resources: translations,
        chunks: translationChunksConfig,
        fallbackLang: 'en',
      },
    }),
    provideConfig(<FeaturesConfig>{
      features: {
        level: '4.0',
      },
    }),
    {
      provide: SearchBoxComponentService,
      useClass: DteSearchBoxComponentService,
    },
  ],
  exports: [],
})
export class DteSpartacusModule {}
