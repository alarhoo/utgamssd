import { NgModule } from '@angular/core';
import { CdcConfig, CdcRootModule, CDC_FEATURE } from "@spartacus/cdc/root";
import { CmsConfig, provideConfig } from "@spartacus/core";

@NgModule({
  declarations: [],
  imports: [
    CdcRootModule
  ],
  providers: [provideConfig(<CmsConfig>{
    featureModules: {
      [CDC_FEATURE]: {
        module: () =>
          import('@spartacus/cdc').then((m) => m.CdcModule),
      },
    }
  }),
  provideConfig(<CdcConfig>{
    cdc: [
      {
        baseSite: 'dtespa',
        javascriptUrl: 'https://cdns.gigya.com/JS/gigya.js/JS/gigya.js?apikey=3_EB-dwKz7OIokREXegU9RZjiWkak5HOm1jVPhDTf_W-bRNMISY1p8eKnjc5jVVF6V',
        sessionExpiration: 3600
      },
    ],
  })
  ]
})
export class CdcFeatureModule { }
