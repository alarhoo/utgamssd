import { Component } from '@angular/core';
import { RoutingService } from '@spartacus/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'business-home',
  template: '<a href="/business">Test</a>',
  styles: [''],
})
export class BusinessHome {
  constructor(private routingService: RoutingService, private router: Router) {
    console.log('home');
    // window.location.href = '/shiftsaveenroll'
    // this.router.navigate(['/business/p/ROOFTOP_SOLAR']);
    setTimeout(() => {
      this.routingService.go({ cxRoute: 'home' });
    }, 1000);
  }
}
