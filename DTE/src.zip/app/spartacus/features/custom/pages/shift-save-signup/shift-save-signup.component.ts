import { Component, OnInit } from '@angular/core';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'shift-save-signup',
  templateUrl: './shift-save-signup.component.html',
  styleUrls: ['./shift-save-signup.component.scss'],
})
export class ShiftSaveSignupComponent implements OnInit {
  header = <HTMLElement>document.querySelector('.header');
  items$: Observable<Observable<any>[]> = of([
    of({
      src: '/assets/shiftsaveimages/Oven.svg',
      title: 'Appliances',
      desc: 'Run your dishwasher, clothes washer and dryer before 3 p.m. and after 7 p.m. to lower your bill.',
    }),
    of({
      src: '/assets/shiftsaveimages/cooling.svg',
      title: 'Cooling',
      desc: 'In summer, begin cooling your home before Peak Hours begin at 3 p.m. on weekdays. Then, raise the temperature by just four degrees during the Peak period. You’ll stay cool and save.',
    }),
    of({
      src: '/assets/shiftsaveimages/Furnace.svg',
      title: 'Heating',
      desc: 'In winter, lower your thermostat to 68 degrees, if possible, during Peak Hours, and also when sleeping and when no one is home. You can save around 3% on heating costs for each degree you lower your thermostat during the winter.',
    }),
    of({
      src: '/assets/shiftsaveimages/Electricity_Savings.svg',
      title: 'Make a Habit of Saving',
      desc: 'Reduce up to 12% of electricity use by unplugging non-essential appliances and devices when you’re not using them. They draw power just by being plugged in. Use a smart strip to turn on and off multiple components  in your home office and entertainment areas.',
     
    }),
    of({
      src: '/assets/shiftsaveimages/LEDBulb.svg',
      title: 'Lighting',
      desc: 'Install LED bulbs to save energy and money. ENERGY STAR®-certified lighting uses up to 90% less energy than traditional incandescent bulbs.',
    }),
    of({
      src: '/assets/shiftsaveimages/DishWasher.svg',
      title: 'Dishwasher',
      desc: 'Continue loading up the dishwasher, but use it in Off-Peak hours. Run full loads in your dishwasher. About the same amount of energy and water are used in each wash, regardless of the load size.',
    }),
    of({
      src: '/assets/shiftsaveimages/Thermostat.svg',
      title: 'Programmable Thermostat',
      desc: 'Install a programmable thermostat to automatically adjust your home temperature during Peak and Off-Peak Hours.',
    }),
    of({
      src: '/assets/shiftsaveimages/Washer1.svg',
      title: 'Clothes Dryer',
      desc: "Fill up your clothes dryer, but don't overload it. The dryer needs space for air circulation to efficiently dry fabrics. And did you know that a longer drying cycle on a low heat setting uses less energy?",
    }),
    of({
      src: '/assets/shiftsaveimages/Washer.svg',
      title: 'Clothes Washer',
      desc: 'Use the cold water setting whenever possible. Heating the water can account for up to 90% of the energy it takes to operate a clothes washer.',
    }),
  ]);
  ngOnInit(): void {
    this.header.style.display = 'none';
  }
  ngAfterViewInit(): void {
    window.dispatchEvent(new Event('resize'));
    document.title = 'DTE Community';
  }
}
