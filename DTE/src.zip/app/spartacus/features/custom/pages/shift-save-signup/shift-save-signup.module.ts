import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShiftSaveSignupComponent } from './shift-save-signup.component';
import { CarouselModule } from '@spartacus/storefront';

@NgModule({
  declarations: [ShiftSaveSignupComponent],
  imports: [CommonModule, CarouselModule],
})
export class ShiftSaveSignupModule {}
