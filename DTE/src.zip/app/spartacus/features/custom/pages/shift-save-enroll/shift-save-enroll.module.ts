import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShiftSaveEnrollComponent } from './shift-save-enroll.component';
import { CarouselModule } from '@spartacus/storefront';

@NgModule({
  declarations: [ShiftSaveEnrollComponent],
  imports: [CommonModule, CarouselModule],
})
export class ShiftSaveEnrollModule {}
