import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CmsConfig, ConfigModule, UrlModule } from '@spartacus/core';
import { OutletPosition, provideOutlet } from '@spartacus/storefront';
import { DteHeaderComponent } from '../../outlets/dte-header/dte-header.component';
import { DteHeaderModule } from '../../outlets/dte-header/dte-header.module';
import { DteLoginModule } from '../../cms/components/dte-login/dte-login.module';
import { DteMinicartModule } from '../../cms/components/dte-minicart/dte-minicart.module';
import { DteBannerModule } from '../../cms/components/dte-banner/dte-banner.module';
import { DteFooterModule } from '../../cms/components/dte-footer/dte-footer.module';
import { DteProductListModule } from '../../cms/components/dte-product-list/dte-product-list.module';
import { DteIconModule } from '../icon/icon.module';
import { DteI18nModule } from '../i18n/i18n.module';
import { DteTabParagraphContainerModule } from '../../cms/components/dte-tab-paragraph-container/dte-tab-paragraph-container.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    UrlModule,
    DteIconModule,
    // DteI18nModule,
    DteHeaderModule,
    DteLoginModule,
    DteMinicartModule,
    DteBannerModule,
    DteFooterModule,
    DteProductListModule,
    DteTabParagraphContainerModule,
    ConfigModule.withConfig({
      layoutSlots: {
        LandingPage2Template: {
          slots: ['Section1', 'Section2B'],
        },
        ProductListPageTemplate: {
          slots: ['ProductLeftRefinements', 'ProductListSlot'],
        },
        SearchResultsListPageTemplate: {
          slots: ['ProductLeftRefinements', 'SearchResultsListSlot'],
        },
        ProductDetailsPageTemplate: {
          slots: ['Tabs']
        }
      },
    } as CmsConfig),
  ],
  providers: [
    provideOutlet({
      id: 'header',
      position: OutletPosition.REPLACE,
      component: DteHeaderComponent,
    }),
  ],
})
export class DteLayoutModule {}
