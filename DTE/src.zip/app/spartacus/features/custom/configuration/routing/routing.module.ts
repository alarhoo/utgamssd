import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ShiftSaveEnrollComponent } from '../../pages/shift-save-enroll/shift-save-enroll.component';
import { ShiftSaveSignupComponent } from '../../pages/shift-save-signup/shift-save-signup.component';
import { ConfigModule, RoutingConfig } from '@spartacus/core';
import { BusinessHome } from '../../pages/business/business-home';

const STATIC_ROUTES: Routes = [
  // {
  //   path: '',
  //   component: BusinessHome,
  //   // redirectTo: '/business',
  //   // pathMatch: 'prefix',
  // },
  {
    data: {
      cxRoute: 'sccpenroll',
    },
    path: 'shiftsaveenroll',
    loadChildren: () =>
      import('../../pages/shift-save-enroll/shift-save-enroll.module').then((m) => m.ShiftSaveEnrollModule),
    component: ShiftSaveEnrollComponent,
  },
  {
    // data: {
    //   cxRoute: 'sccpsignup',
    // },
    path: 'shiftsavesignup',
    loadChildren: () =>
      import('../../pages/shift-save-signup/shift-save-signup.module').then((m) => m.ShiftSaveSignupModule),
    component: ShiftSaveSignupComponent,
  },
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(STATIC_ROUTES),
    ConfigModule.withConfig({
      routing: {
        routes: {
          // home: { paths: ['/business', ''] },
          product: {
            paths: ['p/:productCode'],
          },
          sccpenroll: {
            paths: ['shiftsaveenroll'],
          },
        },
      },
    } as RoutingConfig),
  ],
})
export class DteRoutingModule {}
