import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfigModule, I18nConfig } from '@spartacus/core';
import { translationChunksConfig } from '@spartacus/assets';

const ENGLISH_TRANSLATION = {
  en: {
    common: {
      searchBox: {
        placeholder: 'Search',
      },
    },
  },
};

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ConfigModule.withConfig({
      i18n: {
        resources: {
          ...ENGLISH_TRANSLATION,
        },
        chunks: translationChunksConfig,
        fallbackLang: 'en',
      },
    } as I18nConfig),
  ],
})
export class DteI18nModule {}
