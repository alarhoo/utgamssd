import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfigModule } from '@spartacus/core';
import { IconConfig } from '@spartacus/storefront';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ConfigModule.withConfig(<IconConfig>{
      icon: {
        symbols: {
          CART: 'glyphicon glyphicon-shopping-cart',
          SEARCH: 'glyphicon glyphicon-search',
          GRID: 'glyphicon glyphicon-th-large',
          LIST: 'glyphicon glyphicon-list',
          MENU: 'glyphicon glyphicon-align-justify',
          REMOVE: 'glyphicon glyphicon-remove',
          USER: 'glyphicon glyphicon-user',
        },
      },
    }),
  ],
})
export class DteIconModule {}
