import { Component, OnInit } from '@angular/core';
import { ModalRef, ModalService } from '@spartacus/storefront';

@Component({
  selector: 'dte-rts-projects-component',
  templateUrl: './dte-rts-projects-component.component.html',
  styleUrls: ['./dte-rts-projects-component.scss']
})
export class DteRtsProjectsComponentComponent implements OnInit {
  protected modalRef: ModalRef | undefined;
  optionsList:any;
  activeStep: number;

  constructor(protected modalService: ModalService) { 
    this.activeStep = 1;
  }

  ngOnInit(): void {
  }
  
  openModal(content: any): void {
    this.modalRef = this.modalService.open(content, {
      centered: true,
      size: 'lg',
    });
    const modalInstance = this.modalRef.componentInstance;
   // modalInstance.init();
  }

  closeModal(event: any): void {
    if (this.modalService.getActiveModal() === this.modalRef) {
      this.modalRef.close();
      this.activeStep = 1;
    }
  }

  applyMyself(){
    this.activeStep = 2;
  }

  /*Test Filter */
  updateFilter(option: any){
    console.log(option);
  }

}
