import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DteRtsProjectsComponentModule } from './dte-rts-projects-component/dte-rts-projects-component.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  exports:[DteRtsProjectsComponentModule]
})
export class RtsProductModule { }
