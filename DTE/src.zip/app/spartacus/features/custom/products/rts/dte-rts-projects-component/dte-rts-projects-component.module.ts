import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DteRtsProjectsComponentComponent } from './dte-rts-projects-component.component';
import { DteSelectModule } from '../../../cms/components/dte-select/dte-select.module';
import { ConfigModule } from '@spartacus/core';



@NgModule({
  declarations: [
    DteRtsProjectsComponentComponent
  ],
  imports: [
    CommonModule,
    DteSelectModule,
    ConfigModule.withConfig({
      cmsComponents: {
        RtsMyProjectsComponent: {
          component: DteRtsProjectsComponentComponent,
        },
      },
    })
  ],
  exports:[DteRtsProjectsComponentComponent]
})
export class DteRtsProjectsComponentModule { }
