import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RtsProductModule } from './rts/rts-product.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  exports:[RtsProductModule]
})
export class DteProductsModule { }
