import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dte-header',
  templateUrl: './dte-header.component.html',
  styles: [''],
})
export class DteHeaderComponent implements OnInit {
  ngOnInit(): void {
    const searchIcon: any = document.querySelector('header .mid-header .row cx-searchbox label div.search-icon');
    const searchBox: any = document.querySelector('header .mid-header .row cx-searchbox label.searchbox');
    searchBox.prepend(searchIcon);
    setTimeout(() => {
      const menuWrapper = document.querySelector('dte-header dte-login .HeaderLinks cx-navigation cx-navigation-ui .wrapper') as Node;
      const menuHeader = document.getElementById('menu-header') as HTMLDivElement;
      if (menuWrapper) {
        menuHeader?.appendChild(menuWrapper);
      }
    }, 2000);
  }
}
