import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DteHeaderComponent } from './dte-header.component';
import { CategoryNavigationModule, HamburgerMenuModule, OutletRefModule, PageLayoutModule, PageSlotModule, SearchBoxModule } from '@spartacus/storefront';
import { DteMinicartModule } from '../../cms/components/dte-minicart/dte-minicart.module';
import { UrlModule } from '@spartacus/core';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [DteHeaderComponent],
  imports: [
    CommonModule,
    UrlModule,
    RouterModule,
    OutletRefModule,
    PageLayoutModule,
    PageSlotModule,
    CategoryNavigationModule,
    HamburgerMenuModule,
    SearchBoxModule,
    DteMinicartModule,
  ],
  exports: [DteHeaderComponent],
})
export class DteHeaderModule {}
