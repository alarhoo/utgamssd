import { Injectable } from '@angular/core';
import { EventService, RoutingService, SearchboxService, TranslationService, WindowRef } from '@spartacus/core';
import { SearchBoxComponentService, SearchBoxConfig, SearchResults } from '@spartacus/storefront';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DteSearchBoxComponentService extends SearchBoxComponentService {
  constructor(searchService: SearchboxService, routingService: RoutingService, translationService: TranslationService, winRef: WindowRef, eventService: EventService) {
    super(searchService, routingService, translationService, winRef, eventService);
  }
  getResults(config: SearchBoxConfig): Observable<SearchResults> {
    config.displaySuggestions = false;
    config.minCharactersBeforeRequest = 3;
    return super.getResults(config);
  }
}
