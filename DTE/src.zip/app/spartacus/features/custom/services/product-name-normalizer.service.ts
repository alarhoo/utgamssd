import { Injectable } from '@angular/core';
import { Converter, Occ, Product } from '@spartacus/core';

interface DteProduct extends Product {
  nameForUrl: string;
}

@Injectable({
  providedIn: 'root',
})
export class ProductNameNormalizerService implements Converter<Occ.Product, Product> {
  constructor() {}

  convert(source: Occ.Product, target: DteProduct): DteProduct {
    if (source.name) {
      target.nameForUrl = source.name.replace(/ /g, '-');
      target.nameForUrl = target.nameForUrl.toLowerCase();
    }
    return target;
  }
}
