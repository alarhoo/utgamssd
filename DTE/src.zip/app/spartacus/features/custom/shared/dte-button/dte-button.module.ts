import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DteButtonComponent } from './dte-button.component';



@NgModule({
  declarations: [
    DteButtonComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    DteButtonComponent
  ]
})
export class DteButtonModule { }
