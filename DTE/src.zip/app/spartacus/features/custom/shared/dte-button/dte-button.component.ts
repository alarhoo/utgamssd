import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dte-button',
  templateUrl: './dte-button.component.html',
  styleUrls: ['./dte-button.component.scss']
})
export class DteButtonComponent implements OnInit {

  @Input() btnText: string | undefined = 'texts';
  // btnText = 'test'
  constructor() { }

  ngOnInit(): void {
  }

}
