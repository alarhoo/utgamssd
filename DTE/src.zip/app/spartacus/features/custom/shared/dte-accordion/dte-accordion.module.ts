import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DteAccordionComponent } from './dte-accordion.component';

@NgModule({
  declarations: [DteAccordionComponent],
  imports: [CommonModule],
  exports: [DteAccordionComponent],
})
export class DteAccordionModule {}
