import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: '.app-dte-accordion',
  templateUrl: './dte-accordion.component.html',
  styleUrls: ['./dte-accordion.component.scss'],
})
export class DteAccordionComponent {
  @Input() accTitle!: string;
  collapsed: boolean = true;

  togglePanel() {
    this.collapsed = !this.collapsed;
  }
}
