import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DteSelectComponent } from './dte-select.component';



@NgModule({
  declarations: [
    DteSelectComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [DteSelectComponent]
})
export class DteSelectModule { }
