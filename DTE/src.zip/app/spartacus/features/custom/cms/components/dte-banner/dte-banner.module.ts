import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DteBannerComponent } from './dte-banner.component';
import { CmsConfig, ConfigModule, UrlModule } from '@spartacus/core';
import { MediaModule } from '@spartacus/storefront';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [DteBannerComponent],
  imports: [
    CommonModule,
    MediaModule,
    UrlModule,
    RouterModule,
    ConfigModule.withConfig({
      cmsComponents: {
        DteMediaParagraphComponent: {
          component: DteBannerComponent,
        },
      },
    } as CmsConfig),
  ],
})
export class DteBannerModule {}
