import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dte-account-subscription',
  templateUrl: './dte-account-subscription.component.html',
  styles: [
  ]
})
export class DteAccountSubscriptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
