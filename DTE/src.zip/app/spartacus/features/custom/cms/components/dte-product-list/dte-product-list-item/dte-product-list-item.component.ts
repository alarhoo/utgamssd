import { ChangeDetectionStrategy, Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Product } from '@spartacus/core';
import { ProductListItemContext, ProductListItemContextSource } from '@spartacus/storefront';

@Component({
  selector: 'dte-product-list-item',
  templateUrl: './dte-product-list-item.component.html',
  styles: [],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    ProductListItemContextSource,
    {
      provide: ProductListItemContext,
      useExisting: ProductListItemContextSource,
    },
  ],
})
export class DteProductListItemComponent implements OnChanges {
  @Input() product!: Product;

  constructor(protected productListItemContextSource: ProductListItemContextSource) {}

  ngOnChanges(changes?: SimpleChanges): void {
    if (changes?.product) {
      this.productListItemContextSource.product$.next(this.product);
    }
  }
}
