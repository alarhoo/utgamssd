import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'dte-select',
  templateUrl: './dte-select.component.html',
  styleUrls: ['./dte-select.component.scss'],
})
export class DteSelectComponent implements OnInit {

  @Input() options: any;
  @Input() selectObj: any | undefined;
  @Input() defaultText: string | undefined;
  @Output() getSelected = new EventEmitter<string>();
  activeDropdown: boolean | undefined;

  constructor() { }

  ngOnInit(): void {
    this.activeDropdown = false;
    this.defaultText = this.defaultText ? this.defaultText : 'Select';
    this.options=[{'code':'1','value':'1option1'},{'code':'3','value':'1option3'},{'code':'2','value':'1option2'}];
  }

  updateSelect(option:any){
    this.selectObj = option;
    this.activeDropdown = false;
    this.getSelected.emit(option);
  }

}
