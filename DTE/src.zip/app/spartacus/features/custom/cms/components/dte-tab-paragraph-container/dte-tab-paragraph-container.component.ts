import { AfterViewChecked, Component, ElementRef, OnInit, ViewEncapsulation } from '@angular/core';
import { AuthService, CmsService, CMSTabParagraphContainer, Product, WindowRef } from '@spartacus/core';
import {
  BreakpointService,
  CmsComponentData,
  CurrentProductService,
  MediaService,
  TabParagraphContainerComponent,
} from '@spartacus/storefront';
import { combineLatest, Observable } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

@Component({
  selector: 'dte-tab-paragraph-container',
  templateUrl: './dte-tab-paragraph-container.component.html',
  styleUrls: ['./dte-tab-paragraph-container.component.scss'],
  host: { class: 'dte' },
  encapsulation: ViewEncapsulation.None,
})
export class DteTabParagraphContainerComponent extends TabParagraphContainerComponent implements OnInit {
  isCommerceLoggedIn: string = 'logged-out';
  currentProduct: Product = {};
  children$!: Observable<any[]>[];
  components$: Observable<any[]> = this.componentData.data$.pipe(
    switchMap((data) =>
      combineLatest(
        data.components!.split(' ').map((component) =>
          this.cmsService.getComponentData<any>(component).pipe(
            map((tab) => {
              this.children$ = [];
              if (tab.children) {
                tab.children.split(' ').map((comp: string) => {
                  this.children$.push(this.cmsService.getComponentData<any>(comp));
                });
              }
              if (!tab.flexType) {
                tab = {
                  ...tab,
                  flexType: tab.typeCode,
                };
              }
              return {
                ...tab,
                child$: this.children$,
                title: `CMSTabParagraphContainer.tabs.${tab.uid}`,
              };
            })
          )
        )
      )
    )
  );

  constructor(
    public componentData: CmsComponentData<CMSTabParagraphContainer>,
    protected cmsService: CmsService,
    protected winRef: WindowRef,
    breakpointService: BreakpointService,
    authService: AuthService,
    private elem: ElementRef,
    currentProductService: CurrentProductService,
    public mediaService: MediaService
  ) {
    super(componentData, cmsService, winRef, breakpointService);
    authService.isUserLoggedIn().subscribe((data) => {
      if (data) {
        this.isCommerceLoggedIn = 'logged-in';
      }
    });
    currentProductService.getProduct().subscribe((data) => {
      if (data) {
        this.currentProduct = data;
      }
    });
  }
  
  ngOnInit(): void {
    setTimeout(() => {
      const gotoHref = this.elem.nativeElement.querySelectorAll('.gotoHref');
      gotoHref.forEach((elem: any) => {
        elem.addEventListener('click', () => {
          const tab = elem.dataset.tab;
          const href = elem.dataset.href;
          const active = this.elem.nativeElement.querySelector(`.dte-tab-header.active`).classList.contains(tab);
          if (!active) {
            this.elem.nativeElement.querySelector(`.dte-tab-header.${tab}`).click();
          }
          setTimeout(() => {
            this.elem.nativeElement.querySelector(href).scrollIntoView({ behavior: 'smooth', block: 'start' });
          }, 100);
        });
      });
    }, 3000);
  }

  select(tabNum: number, event?: MouseEvent): void {
    this.activeTabNum = this.activeTabNum === tabNum ? -1 : tabNum;
  }

}
