import { Component, ElementRef } from '@angular/core';
import { AuthService } from '@spartacus/core';
import { LoginComponent } from '@spartacus/user/account/components';
import { UserAccountFacade } from '@spartacus/user/account/root';

@Component({
  selector: 'dte-login',
  templateUrl: './dte-login.component.html',
  styles: [''],
})
export class DteLoginComponent extends LoginComponent {
  constructor(auth: AuthService, userAccount: UserAccountFacade, private elem: ElementRef) {
    super(auth, userAccount);
  }
  public openMenu(_event: any) {
    const menuHeader = document.getElementById('menu-header');
    const myAccount = this.elem.nativeElement.querySelector('.my-account');
    menuHeader?.classList.toggle('d-none');
    myAccount.classList.toggle('clicked');
  }
}
