import { Component, OnInit } from '@angular/core';
import { UserAddressService } from '@spartacus/core';
import { AddressBookComponent, CmsComponentData } from '@spartacus/storefront';

@Component({
  selector: 'dte-account-address-book',
  templateUrl: './dte-account-address-book.component.html',
  styles: [''],
})
export class DteAccountAddressBookComponent extends AddressBookComponent implements OnInit {
  // constructor(public component: AddressBookComponent) {
  //   console.log(component);
  // }

  ngOnInit(): void {
    this.service.getAddresses().subscribe(console.log)
    console.log(this.showAddAddressForm);
    console.log(this.currentAddress);
  }
}
