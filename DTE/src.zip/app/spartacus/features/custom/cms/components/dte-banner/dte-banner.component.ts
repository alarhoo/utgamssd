import { Component, OnInit } from '@angular/core';
import { CmsBannerComponent } from '@spartacus/core';
import { CmsComponentData } from '@spartacus/storefront';

@Component({
  selector: 'dte-banner',
  templateUrl: './dte-banner.component.html',
  styles: [''],
})
export class DteBannerComponent {
  constructor(public component: CmsComponentData<CmsBannerComponent>) {}
}
