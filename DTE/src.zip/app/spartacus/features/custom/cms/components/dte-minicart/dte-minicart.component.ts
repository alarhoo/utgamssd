import { Component, OnInit } from '@angular/core';
import { MiniCartComponent } from '@spartacus/storefront';

@Component({
  selector: 'dte-minicart',
  templateUrl: './dte-minicart.component.html',
  styles: [''],
})
export class DteMinicartComponent extends MiniCartComponent {}
