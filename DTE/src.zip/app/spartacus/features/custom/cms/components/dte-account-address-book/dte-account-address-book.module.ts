import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CmsConfig, ConfigModule } from '@spartacus/core';
import { DteAccountAddressBookComponent } from './dte-account-address-book.component';

@NgModule({
  declarations: [DteAccountAddressBookComponent],
  imports: [
    CommonModule,
    ConfigModule.withConfig({
      cmsComponents: {
        AccountAddressBookComponent: {
          // component: DteAccountAddressBookComponent,
        },
      },
    }),
  ],
})
export class DteAccountAddressBookModule {}
