import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DteAccountSubscriptionComponent } from './dte-account-subscription.component';
import { CmsConfig, ConfigModule } from '@spartacus/core';

@NgModule({
  declarations: [DteAccountSubscriptionComponent],
  imports: [
    CommonModule,
    ConfigModule.withConfig({
      cmsComponents: {
        AccountSubscriptionComponent: {
          component: DteAccountSubscriptionComponent,
        },
      },
    } as CmsConfig),
  ],
  exports: [DteAccountSubscriptionComponent],
})
export class DteAccountSubscriptionModule {}
