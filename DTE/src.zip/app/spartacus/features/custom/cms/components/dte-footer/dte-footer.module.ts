import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DteFooterComponent } from './dte-footer.component';
import { CmsConfig, ConfigModule } from '@spartacus/core';
import { NavigationModule } from '@spartacus/storefront';

@NgModule({
  declarations: [DteFooterComponent],
  imports: [
    CommonModule,
    NavigationModule,
    ConfigModule.withConfig({
      cmsComponents: {
        FooterNavigationComponent: {
          component: DteFooterComponent,
        },
      },
    } as CmsConfig),
  ],
})
export class DteFooterModule {}
