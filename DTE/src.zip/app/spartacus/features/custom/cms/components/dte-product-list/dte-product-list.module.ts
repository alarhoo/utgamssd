import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { DteProductListComponent } from './dte-product-list.component';
import { ConfigModule, I18nModule, UrlModule } from '@spartacus/core';
import { ListNavigationModule, MediaModule, PaginationModule, ProductFacetNavigationModule, ProductListModule } from '@spartacus/storefront';
import { DteProductGridItemComponent } from './dte-product-grid-item/dte-product-grid-item.component';
import { DteProductListItemComponent } from './dte-product-list-item/dte-product-list-item.component';

@NgModule({
  declarations: [DteProductListComponent, DteProductListItemComponent, DteProductGridItemComponent],
  imports: [
    CommonModule,
    I18nModule,
    MediaModule,
    ProductListModule,
    PaginationModule,
    ListNavigationModule,
    ProductFacetNavigationModule,
    UrlModule,
    RouterModule,
    ConfigModule.withConfig({
      cmsComponents: {
        CMSProductListComponent: {
          component: DteProductListComponent,
        },
        SearchResultsListComponent: {
          component: DteProductListComponent,
        },
      },
    }),
  ],
  exports: [DteProductListItemComponent, DteProductGridItemComponent],
})
export class DteProductListModule {}
