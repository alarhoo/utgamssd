import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DteLoginComponent } from './dte-login.component';
import { ConfigModule, I18nModule, UrlModule } from '@spartacus/core';
import { IconModule, OutletRefModule, PageLayoutModule, PageSlotModule } from '@spartacus/storefront';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [DteLoginComponent],
  imports: [
    CommonModule,
    I18nModule,
    UrlModule,
    IconModule,
    PageSlotModule,
    RouterModule,
    ConfigModule.withConfig({
      cmsComponents: {
        LoginComponent: {
          component: DteLoginComponent,
        },
      },
    }),
  ],
})
export class DteLoginModule {}
