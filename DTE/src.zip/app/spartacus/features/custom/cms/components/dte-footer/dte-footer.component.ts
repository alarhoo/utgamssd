import { Component } from '@angular/core';
import { CmsNavigationComponent } from '@spartacus/core';
import { CmsComponentData, FooterNavigationComponent, NavigationService } from '@spartacus/storefront';

@Component({
  selector: 'dte-footer',
  templateUrl: './dte-footer.component.html',
  styles: [''],
})
export class DteFooterComponent extends FooterNavigationComponent {
  constructor(public component: CmsComponentData<CmsNavigationComponent>, protected service: NavigationService) {
    super(component, service);
  }
}
