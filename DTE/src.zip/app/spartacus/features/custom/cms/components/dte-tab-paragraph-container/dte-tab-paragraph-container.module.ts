import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DteTabParagraphContainerComponent } from './dte-tab-paragraph-container.component';
import { CmsConfig, ConfigModule, I18nModule, UrlModule } from '@spartacus/core';
import { MediaModule, OutletModule, PageComponentModule } from '@spartacus/storefront';
import { RouterModule } from '@angular/router';
import { SafeHtmlModule } from '../../../configuration/pipe/safe-html/safe-html.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DteSelectModule } from '../dte-select/dte-select.module';
import { DteProductsModule } from '../../../products/dte-products.module';


@NgModule({
  declarations: [DteTabParagraphContainerComponent],
  imports: [
    CommonModule,
    MediaModule,
    NgbModule,
    UrlModule,
    RouterModule,
    PageComponentModule,
    OutletModule,
    I18nModule,
    SafeHtmlModule,
    DteSelectModule,
    DteProductsModule,
    ConfigModule.withConfig({
      cmsComponents: {
        CMSTabParagraphContainer: {
          component: DteTabParagraphContainerComponent,
        },
      },
    } as CmsConfig),
  ],
})
export class DteTabParagraphContainerModule {}
