import { Component, Input, OnChanges, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { Product } from '@spartacus/core';
import { ProductListItemContext, ProductListItemContextSource } from '@spartacus/storefront';

@Component({
  selector: 'dte-product-grid-item',
  templateUrl: './dte-product-grid-item.component.html',
  styles: [],
  encapsulation: ViewEncapsulation.None,
  providers: [
    ProductListItemContextSource,
    {
      provide: ProductListItemContext,
      useExisting: ProductListItemContextSource,
    },
  ],
})
export class DteProductGridItemComponent implements OnChanges {
  @Input() product!: Product;
  constructor(protected productListItemContextSource: ProductListItemContextSource) {}

  ngOnChanges(changes?: SimpleChanges): void {
    if (changes?.product) {
      this.productListItemContextSource.product$.next(this.product);
    }
  }
}
