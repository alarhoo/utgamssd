import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DteMinicartComponent } from './dte-minicart.component';
import { ConfigModule, I18nModule, UrlModule } from '@spartacus/core';
import { IconModule } from '@spartacus/storefront';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [DteMinicartComponent],
  imports: [
    CommonModule,
    I18nModule,
    IconModule,
    UrlModule,
    RouterModule,
    ConfigModule.withConfig({
      cmsComponents: {
        MiniCartComponent: {
          component: DteMinicartComponent,
        },
      },
    }),
  ],
  exports: [DteMinicartComponent],
})
export class DteMinicartModule {}
