import { Component, ViewEncapsulation } from '@angular/core';
import { PageLayoutService, ProductListComponent, ProductListComponentService, ViewConfig } from '@spartacus/storefront';

@Component({
  selector: 'dte-product-list',
  templateUrl: './dte-product-list.component.html',
  styleUrls: ['./dte-product-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class DteProductListComponent extends ProductListComponent {
  constructor(pageLayoutService: PageLayoutService, productListComponentService: ProductListComponentService, scrollConfig: ViewConfig) {
    super(pageLayoutService, productListComponentService, scrollConfig);
    super.ngOnInit();
  }
}
