import { NgModule } from '@angular/core';
import { CdcConfig, CdcRootModule, CDC_FEATURE } from '@spartacus/cdc/root';
import { provideConfig } from '@spartacus/core';

@NgModule({
  declarations: [],
  imports: [CdcRootModule],
  providers: [
    provideConfig({
      featureModules: {
        [CDC_FEATURE]: {
          module: () => import('@spartacus/cdc').then((m) => m.CdcModule),
        },
      },
    }),
    provideConfig(<CdcConfig>{
      cdc: [
        {
          baseSite: 'dtespa',
          javascriptUrl: 'https://fidm.gigya.com/saml/v2.0/3_EB-dwKz7OIokREXegU9RZjiWkak5HOm1jVPhDTf_W-bRNMISY1p8eKnjc5jVVF6V',
          sessionExpiration: 3600,
        },
      ],
    }),
  ],
})
export class CdcFeatureModule {}