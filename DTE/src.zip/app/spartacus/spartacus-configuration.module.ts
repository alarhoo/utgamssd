import { NgModule } from '@angular/core';
import { translationChunksConfig, translations } from '@spartacus/assets';
import { FeaturesConfig, I18nConfig, OccConfig, provideConfig, SiteContextConfig, AuthConfig } from '@spartacus/core';
import { defaultB2bCheckoutConfig, defaultB2bOccConfig } from '@spartacus/setup';
import { defaultCmsContentProviders, layoutConfig, mediaConfig } from '@spartacus/storefront';
import { CdcConfig, CdcRootModule, CDC_FEATURE } from '@spartacus/cdc/root';
import { environment } from '../../environments/environment';

@NgModule({
  declarations: [],
  imports: [CdcRootModule],
  providers: [
    provideConfig(layoutConfig),
    provideConfig(mediaConfig),
    ...defaultCmsContentProviders,
    //  For the local login comment out the provideConfig(<OccConfig> and provideConfig(<AuthConfig> below
    provideConfig(<OccConfig>{
      authentication: {
        client_id: 'mobile_android',
        client_secret: 'secret',
        OAuthLibConfig: {
          responseType: 'token',
          scope: 'basic',
        },
      },
    }),
    provideConfig(<AuthConfig>{
      authentication: {
        //baseUrl: environment.occBaseUrl,
        loginUrl: '../occ/oauth/authorize',
        revokeEndpoint: '../authorizationserver/oauth/revoke',
        logoutUrl: '../occ/oauth/signout',
        OAuthLibConfig: {
          requireHttps: false,
          responseType: 'token',
          scope: 'basic',
          postLogoutRedirectUri: '/',
        },
      },
    }),
    provideConfig(<I18nConfig>{
      i18n: {
        resources: translations,
        chunks: translationChunksConfig,
        fallbackLang: 'en',
      },
    }),
    provideConfig(<FeaturesConfig>{
      features: {
        level: '4.0',
      },
    }),
    provideConfig({
      featureModules: {
        [CDC_FEATURE]: {
          module: () => import('@spartacus/cdc').then((m) => m.CdcModule),
        },
      },
      // context: {
      //   baseSite: ['business'],
      //   urlParameters: ['baseSite'],
      // },
    }),
    // provideConfig(<CdcConfig>{
    //   cdc: [
    //     {
    //       baseSite: 'business',
    //       javascriptUrl:
    //         'https://cdns.gigya.com/JS/gigya.js?apiKey=3_EB-dwKz7OIokREXegU9RZjiWkak5HOm1jVPhDTf_W-bRNMISY1p8eKnjc5jVVF6V',
    //       sessionExpiration: 3600,
    //     },
    //   ],
    // }),
  ],
})
export class SpartacusConfigurationModule {}
