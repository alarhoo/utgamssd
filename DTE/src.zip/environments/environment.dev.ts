export const environment = {
  production: false,
  occBaseSite: 'dtespa',
  occBaseUrl: 'https://api.cjmmnmayt-dteelectr1-d1-public.model-t.cc.commerce.ondemand.com',
  occApiPrefix: '/occ/v2/',
  gigyaCdn: 'https://cdns.gigya.com/JS/gigya.js?apiKey=3_EB-dwKz7OIokREXegU9RZjiWkak5HOm1jVPhDTf_W-bRNMISY1p8eKnjc5jVVF6V',
};
