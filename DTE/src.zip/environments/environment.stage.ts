export const environment = {
  production: false,
  gigyaCdn: 'https://cdns.gigya.com/JS/gigya.js?apiKey=3_e_qjd_hIEv1YYw2ihp_u8_g0aH6VU8krGaXYYJgWWi-XzqmCBGsmZOYvhauDmlzp',
};
