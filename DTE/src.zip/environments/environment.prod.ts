export const environment = {
  production: true,
  gigyaCdn: 'https://cdns.gigya.com/JS/gigya.js?apiKey=3_IknTdQPh8NIyW_0pVYLPmziu8er4eZ1ctY9TzbA74QY7GyJ-ccAYYZ5JzVdIYA2l',
};
