import pyodbc
from datetime import datetime, timedelta
from sendBirthdayEmail import sendBirthdayEmail
from sendAnniversaryEmail import sendAnniversaryEmail
import traceback
import logging
logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
# logging.basicConfig(format="%(asctime)s - %(message)s", level=logging.INFO)

theday = datetime.today().date()+timedelta(days=-8)

def isToday(dob):
    # Returns True if Birthday/Anniversary is Today else False
    today = theday #datetime.today().date()
    return dob.month == today.month and dob.day == today.day

def main():
    logging.info('Parsing employees for ' + str(theday))
    # Parse EmployeesMain.csv and check if anyone has a Birthday today
    data = []
    try:
        conn = pyodbc.connect(Driver='{SQL Server Native Client 11.0}',Server='utegration.database.windows.net',Database='Utegration_Uplan',Uid='utegration',Pwd='Utguplan2018')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM dbo.EmployeesMain')

        for row in cursor:
            emp_main_dob = row[4]
            emp_main_doj = row[14]
            emp_main_active = row[16]
            # Check if anyone has birthday Today()
            if(isToday(emp_main_dob) and emp_main_active):
                emp_main_first = row[1]
                emp_main_last = row[3]
                emp_main_gender = row[5]
                emp_main_email = row[7]
                emp_main_designation = row[9]
                data.append([emp_main_first, emp_main_last, emp_main_dob, emp_main_gender, emp_main_email, emp_main_designation])
                logging.info('Sending Birthday Email to ' + emp_main_first)
                sendBirthdayEmail(emp_main_first, emp_main_last, emp_main_dob, emp_main_gender, emp_main_email, emp_main_designation)
                
            # Check if anyone has anniversary Today()
            if(isToday(emp_main_doj) and emp_main_active):
                emp_main_first = row[1]
                emp_main_last = row[3]
                emp_main_gender = row[5]
                emp_main_email = row[7]
                emp_main_designation = row[9]
                data.append([emp_main_first, emp_main_last, emp_main_gender, emp_main_email, emp_main_designation, emp_main_doj])
                logging.info('Sending Anniversary Email to ' + emp_main_first)
                sendAnniversaryEmail(emp_main_first, emp_main_last, emp_main_gender, emp_main_email, emp_main_designation, emp_main_doj)
        print(data)
    except Exception as e:
        logging.error("Something went wrong while parsing!")
        logging.error(traceback.format_exc())

main()