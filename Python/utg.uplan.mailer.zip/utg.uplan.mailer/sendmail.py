from flask import Flask
from flask_mail import Mail, Message
import os

app = Flask(__name__)

mail_settings = {
    "MAIL_SERVER": 'smtp.office365.com',
    "MAIL_USE_TLS": True,
    "MAIL_USE_SSL": False,
    "MAIL_PORT": 995,
    "MAIL_USERNAME": 'noreplyindia@utegration.com',
    "MAIL_PASSWORD": 'UtegrationIndia@201801'
}

app.config.update(mail_settings)
mail = Mail(app)

if __name__ == '__main__':
    with app.app_context():
        msg = Message(
            sender=app.config.get('MAIL_USERNAME'),
            recipients=['manjunatha.kashirudraiah@utegration.com'])
        msg.subject = 'Email via Flask'
        msg.body = """ This is cool!! """
        mail.send(msg)

# import smtplib, ssl
# from email.mime.text import MIMEText
# from email.mime.multipart import MIMEMultipart

# sender_email = 'noreplyindia@utegration.com'
# receiver_email = 'manjunatha.kashirudraiah@utegration.com'
# password = 'UtegrationIndia@201801'
# smtp_host = 'smtp.office365.com'
# smtp_port = 995
# message = MIMEMultipart("alternative")
# message["Subject"] = "multipart test"
# message["From"] = sender_email
# message["To"] = receiver_email

# # Create the plain-text and HTML version of your message
# text = """\
# Hi,
# How are you?
# Real Python has many great tutorials:
# www.realpython.com"""
# html = """\
# <html>
#   <body>
#     <p>Hi,<br>
#        How are you?<br>
#        <a href="http://www.realpython.com">Real Python</a> 
#        has many great tutorials.
#     </p>
#   </body>
# </html>
# """

# # Turn these into plain/html MIMEText objects
# part1 = MIMEText(text, "plain")
# part2 = MIMEText(html, "html")

# # Add HTML/plain-text parts to MIMEMultipart message
# # The email client will try to render the last part first
# message.attach(part1)
# message.attach(part2)

# # Create secure connection with server and send email
# context = ssl.create_default_context()
# with smtplib.SMTP("smtp.office365.com", 587) as smtpServer:
#     smtpServer.login(sender_email, password)
#     smtpServer.sendmail(sender_email, receiver_email, message.as_string())
# # with smtplib.SMTP_SSL(smtp_host, smtp_port, context=context) as server:
# #     server.login(sender_email, password)
# #     server.sendmail(sender_email, receiver_email, message.as_string())