import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import ApiConfig from '../config/default.json';

@Injectable({
  providedIn: 'root',
})
export class RestApiService {
  constructor(private httpClient: HttpClient) {}

  getDataFromApi(sApiCode: string): any {
    return this.httpClient
      .get(ApiConfig.rest_endpoint_config.miss_read_summary[sApiCode])
      .pipe(catchError(this.handleError));
  }

  private handleError(err: HttpErrorResponse): any {
    return throwError(`An error occurred: ${err.status}: ${err.message}`);
  }
}
