import { DOCUMENT } from '@angular/common';
import {
  Component,
  ChangeDetectorRef,
  OnInit,
  OnDestroy,
  Inject,
  ViewChild,
} from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import {
  Router,
  Event,
  NavigationStart,
  NavigationEnd,
  NavigationCancel,
  NavigationError,
} from '@angular/router';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
dayjs.extend(relativeTime);
import { OverlayContainer } from '@angular/cdk/overlay';
import { LoaderService } from 'src/app/services/loader.service';
import { RestApiService } from 'src/app/services/rest-api.service';
import { MatDialog } from '@angular/material/dialog';
import { ApexOptions } from 'apexcharts';
import { ApexChart } from 'ng-apexcharts';

declare global {
  interface Window {
    Apex: any;
  }
}

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss'],
})
export class LayoutComponent implements OnInit, OnDestroy {
  panelOpenState = false;
  isDarkTheme = true;
  // isLoading = true;
  collapsedNav = true;
  mobileQuery: MediaQueryList;
  chart: ApexChart;
  options: ApexOptions;
  LastAccessTime = dayjs().startOf('day').fromNow();
  elem;
  isFullScreen: boolean;
  showSearchbar = false;
  showNavigationProgressBar = false;

  @ViewChild('snav') snav;
  private mobileQueryListener: () => void;
  constructor(
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher,
    public loaderService: LoaderService,
    private router: Router,
    public dialog: MatDialog,
    public overlayContainer: OverlayContainer,
    public apiService: RestApiService,
    @Inject(DOCUMENT) private document: any // public apexOptions: ApexOptions
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this.mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addEventListener('change', this.mobileQueryListener);
    // console.log(apexOptions);
    this.router.events.subscribe((routerEvent: Event) => {
      if (routerEvent instanceof NavigationStart) {
        this.showNavigationProgressBar = true;
      }
      if (
        routerEvent instanceof NavigationEnd ||
        routerEvent instanceof NavigationCancel ||
        routerEvent instanceof NavigationError
      ) {
        this.showNavigationProgressBar = false;
      }
    });
  }
  sideNavToggle(): void {
    this.mobileQuery.matches
      ? this.snav.toggle()
      : (this.collapsedNav = !this.collapsedNav);
    this.triggerWindowResize();
  }
  checkScreenMode(): void {
    if (document.fullscreenElement) {
      this.isFullScreen = true;
    } else {
      this.isFullScreen = false;
    }
  }
  signOut(): void {
    console.log(`User logger out`);
    this.router.navigateByUrl('/');
  }
  sendFeedback(): void {
    this.dialog.open(FeedbackDialogComponent);
  }
  changeSettings(): void {
    this.dialog.open(SettingsDialogComponent);
  }
  changeTheme(): void {
    this.isDarkTheme = true ? localStorage.getItem('theme') === 'MA4UDark' : false;
    if (this.isDarkTheme) {
      this.overlayContainer.getContainerElement().classList.add('dark-theme');
      window.Apex = {
        chart: {
          foreColor: '#ccc',
        },
        theme: { mode: 'dark' },
      };
    } else {
      this.overlayContainer
        .getContainerElement()
        .classList.remove('dark-theme');
      window.Apex = {
        chart: {
          foreColor: '#000000de',
        },
        theme: { mode: 'light' },
      };
    }
  }
  ngOnDestroy(): void {
    this.mobileQuery.removeEventListener('change', this.mobileQueryListener);
  }
  openSearchbar(): void {
    console.log('ok');
    this.showSearchbar = !this.showSearchbar;
  }
  toggleTheme(): void {
    localStorage.setItem('theme', this.isDarkTheme ? 'MA4UDark' : 'MA4ULight');
    this.changeTheme();
  }
  ngOnInit(): void {
    this.elem = document.documentElement;
    // console.log(document.documentElement.requestFullscreen);
    this.checkScreenMode();
    this.changeTheme();
    this.triggerWindowResize();
  }

  openFullscreen(): void {
    this.checkScreenMode();
    if (this.elem.requestFullscreen) {
      this.elem.requestFullscreen();
      this.isFullScreen = !this.isFullScreen;
    } else if (this.elem.mozRequestFullScreen) {
      /* Firefox */
      this.elem.mozRequestFullScreen();
    } else if (this.elem.webkitRequestFullscreen) {
      /* Chrome, Safari and Opera */
      this.elem.webkitRequestFullscreen();
    } else if (this.elem.msRequestFullscreen) {
      /* IE/Edge */
      this.elem.msRequestFullscreen();
    }
  }

  /* Close fullscreen */
  closeFullscreen(): void {
    this.checkScreenMode();
    if (this.document.exitFullscreen) {
      this.document.exitFullscreen();
      this.isFullScreen = !this.isFullScreen;
    } else if (this.document.mozCancelFullScreen) {
      /* Firefox */
      this.document.mozCancelFullScreen();
    } else if (this.document.webkitExitFullscreen) {
      /* Chrome, Safari and Opera */
      this.document.webkitExitFullscreen();
    } else if (this.document.msExitFullscreen) {
      /* IE/Edge */
      this.document.msExitFullscreen();
    }
  }

  triggerWindowResize(): void {
    console.log('Window Resize...');
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 1000);
  }
}

@Component({
  selector: 'app-feedback-dialog',
  templateUrl: 'feedback.dialog.html',
})
export class FeedbackDialogComponent {}

@Component({
  selector: 'app-settings-dialog',
  templateUrl: 'settings.dialog.html',
})
export class SettingsDialogComponent {}
