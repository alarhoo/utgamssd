import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { missreaddata } from './data';
import { RestApiService } from 'src/app/services/rest-api.service';

@Component({
  selector: 'app-opt-out-detail',
  templateUrl: './opt-out-detail.component.html',
  styles: [''],
})
export class OptOutDetailComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatTable) table: MatTable<any>;
  ELEMENT_DATA: any[] = [];
  selection = new SelectionModel<any>(true, []);

  displayedColumns: string[] = [
    'select',
    'INSTALLATION',
    'MTR_ID',
    'METER_CATEGORY',
    'METER_INSTALLATION_DATE',
    'RADIO_STATUS',
    'HES_METER_STATUS',
    'MDM_METER_STATUS',
    'SAP_METER_STATUS',
    'OPT_OUT_START_DATE',
  ];

  dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);

  constructor(private apiService: RestApiService) {}

  ngOnInit(): void {
    this.getDataForOptOutDetailTable();
  }

  getDataForOptOutDetailTable(): void {
    this.apiService.getDataFromApi('apiForOptOutDetail').subscribe({
      next: (optOutDetail) => {
        this.dataSource.data = optOutDetail;
      },
    });
    this.dataSource.data = missreaddata;
  }
  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected(): any {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle(): void {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.data.forEach((row) => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: any): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.position + 1
    }`;
  }
}
