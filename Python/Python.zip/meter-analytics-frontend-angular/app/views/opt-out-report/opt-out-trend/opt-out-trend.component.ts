import { Component, OnInit } from '@angular/core';
import { ChartOptions } from '../../shared/chartOptions';
import { RestApiService } from 'src/app/services/rest-api.service';

@Component({
  selector: 'app-opt-out-trend',
  templateUrl: './opt-out-trend.component.html',
  styles: [''],
})
export class OptOutTrendComponent implements OnInit {
  public optOutTrendChartOptions: Partial<ChartOptions>;

  constructor(private apiService: RestApiService) {}

  ngOnInit(): void {
    this.getDataForOptOutTrendChart();
  }

  getDataForOptOutTrendChart(): void {
    this.optOutTrendChartOptions = {
      series: [],
      chart: {
        type: 'line',
        width: '100%',
        height: '300px',
        dropShadow: {
          enabled: true,
        },
        toolbar: {
          show: false,
        },
      },
      title: {
        text: '',
      },
      noData: {
        text: 'Loading...',
      },
      xaxis: {
        categories: [],
        labels: {},
      },
      legend: {
        position: 'top',
        horizontalAlign: 'center',
      },
    };

    this.apiService.getDataFromApi('apiForOptOutTrend').subscribe({
      next: (trendItems) => {
        const series = [{ name: '2019', data: [] }, { name: '2020', data: [] }];
        this.optOutTrendChartOptions.series = this.getChartData(
          trendItems,
          'datetime',
          'YYYYMM',
          series
        );
      },
    });
  }

  getChartData(data: any, type: string, xaxis: string, series: any): any {
    if (type === 'datetime') {
      const xCategory = [];
      data.forEach((elem: any) => {
        xCategory.push(elem[xaxis]);
        series.forEach((s, i) => {
          series[i].data.push({
            x: elem[xaxis],
            y: elem['YYYY_' + series[i].name],
          });
        });
      });
      return series;
    }
  }
}
