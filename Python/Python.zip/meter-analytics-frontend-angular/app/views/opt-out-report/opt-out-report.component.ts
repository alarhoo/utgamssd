import { Component, OnInit } from '@angular/core';
import { RestApiService } from 'src/app/services/rest-api.service';

@Component({
  selector: 'app-opt-out-report',
  templateUrl: './opt-out-report.component.html',
  styles: [''],
})
export class OptOutReportComponent implements OnInit {
  // properties for KPI cards
  public oKPIDataForOptOut: {
    icon: string;
    title: string;
    value: string;
    color: string;
    isNumber: boolean;
    tooltip: string;
    isPercent: boolean;
  }[] = [];

  constructor(private apiService: RestApiService) {}

  ngOnInit(): void {
    this.getDataForOptOutKPICards();
  }

  getDataForOptOutKPICards(): void {
    const totalCountResponse = this.apiService.getDataFromApi(
      'apiForOptOutTotalCount'
    );
    totalCountResponse.subscribe((d: any) => {
      this.oKPIDataForOptOut[0] = ({
        icon: 'supervised_user_circle',
        title: 'Total Customers',
        value: d[0].TOTAL_CUSTOMERS,
        color: 1000 < 999 ? '#f44336' : '#039be5',
        isNumber: true,
        tooltip: `Theshold value is 999`,
        isPercent: false,
      });
    });

    const totalActiveCountResponse = this.apiService.getDataFromApi(
      'apiForOptOutTotalActiveCount'
    );
    totalActiveCountResponse.subscribe((d: any) => {
      this.oKPIDataForOptOut[1] = ({
        icon: 'supervised_user_circle',
        title: 'Active Customers',
        value: d[0].TOTAL_ACTIVE_CUSTOMERS,
        color: 1000 < 999 ? '#f44336' : '#039be5',
        isNumber: true,
        tooltip: `Theshold value is 999`,
        isPercent: false,
      });
    });

    const totalOptOutCountResponse = this.apiService.getDataFromApi(
      'apiForOptOutTotalOptOutCount'
    );
    totalOptOutCountResponse.subscribe((d: any) => {
      this.oKPIDataForOptOut[2] = ({
        icon: 'supervised_user_circle',
        title: 'Opt-Out Customers',
        value: d[0].TOTAL_OPT_OUT_CUSTOMERS,
        color: 1000 < 999 ? '#f44336' : '#039be5',
        isNumber: true,
        tooltip: `Theshold value is 999`,
        isPercent: false,
      });
    });

    const avgServiceOrderResponse = this.apiService.getDataFromApi(
      'apiForOptOutAvgServiceOrder'
    );
    avgServiceOrderResponse.subscribe((d: any) => {
      this.oKPIDataForOptOut[3] = ({
        icon: 'done_all',
        title: 'Avg Time for Opt Out Svc Orders Completion',
        value: `${d[0].AVG_SERVICE_ORDER} days`,
        color: 1000 < 999 ? '#039be5' : '#388E3C',
        isNumber: false,
        tooltip: `Theshold value is 999`,
        isPercent: true,
      });
    });

    const outStandingServiceOrder = this.apiService.getDataFromApi(
      'apiForOptOutServiceOrder'
    );
    outStandingServiceOrder.subscribe((d: any) => {
      this.oKPIDataForOptOut[4] = ({
        icon: 'cancel',
        title: 'Outstanding Opt Out Svc Orders',
        value: `${d[0].OUTSTANDING_SERVICE_ORDERS}`,
        color: 1000 < 999 ? '#f44336' : '#FFB300',
        isNumber: false,
        tooltip: `Theshold value is 999`,
        isPercent: true,
      });
    });
  }
}
