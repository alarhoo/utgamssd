import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-revenue-protection-report',
  templateUrl: './revenue-protection-report.component.html',
  styles: []
})
export class RevenueProtectionReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
