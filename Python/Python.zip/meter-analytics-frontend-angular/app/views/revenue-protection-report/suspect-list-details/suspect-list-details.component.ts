import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FormBuilder, AbstractControl } from '@angular/forms';

export interface PeriodicElement {
  DETECTION_TYPE: string;
  TIMESTAMP: string;
  SERVICE_ORDER: string;
  ESIID: string;
  METER_NUM: string;
  SUSPECT_NAME: string;
  CONFIDENCE: string;
  CREW_ONSITE: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    DETECTION_TYPE: 'Disconnect Tamper',
    TIMESTAMP: '2020-02-01 08:44:22',
    SERVICE_ORDER: '12345-S1',
    ESIID: '100888212342',
    METER_NUM: '123234',
    SUSPECT_NAME: 'Nancy Joseph',
    CONFIDENCE: '90',
    CREW_ONSITE: 'CREW',
  },
  {
    DETECTION_TYPE: 'Outage Tamper',
    TIMESTAMP: '2020-02-01 03:14:24',
    SERVICE_ORDER: '12345-S1',
    ESIID: '100888212322',
    METER_NUM: '321421',
    SUSPECT_NAME: 'David Anderson',
    CONFIDENCE: '95',
    CREW_ONSITE: 'CREW',
  },
  {
    DETECTION_TYPE: 'Disconnect Tamper',
    TIMESTAMP: '2020-02-02 05:45:25',
    SERVICE_ORDER: '12345-S1',
    ESIID: '100888212897',
    METER_NUM: '854930',
    SUSPECT_NAME: 'Kevin Clemons',
    CONFIDENCE: '80',
    CREW_ONSITE: 'CREW',
  },
  {
    DETECTION_TYPE: 'Disconnect Tamper',
    TIMESTAMP: '2020-02-03 18:14:12',
    SERVICE_ORDER: '12345-S1',
    ESIID: '100888216548',
    METER_NUM: '325124',
    SUSPECT_NAME: 'Joshy Joseph',
    CONFIDENCE: '90',
    CREW_ONSITE: 'CREW',
  },
  {
    DETECTION_TYPE: 'Disconnect Tamper',
    TIMESTAMP: '2020-02-07 08:34:02',
    SERVICE_ORDER: '12345-S1',
    ESIID: '100888212319',
    METER_NUM: '948339',
    SUSPECT_NAME: 'Angela White',
    CONFIDENCE: '93',
    CREW_ONSITE: 'CREW',
  },
  {
    DETECTION_TYPE: 'Load Side Voltage',
    TIMESTAMP: '2020-02-08 12:24:09',
    SERVICE_ORDER: '12345-S1',
    ESIID: '100888213342',
    METER_NUM: '784939',
    SUSPECT_NAME: 'Pamela Beesly',
    CONFIDENCE: '95',
    CREW_ONSITE: 'CREW',
  },
  {
    DETECTION_TYPE: 'Outage Tamper',
    TIMESTAMP: '2020-03-01 18:54:32',
    SERVICE_ORDER: '12345-S1',
    ESIID: '100888212545',
    METER_NUM: '539231',
    SUSPECT_NAME: 'David Hugh',
    CONFIDENCE: '90',
    CREW_ONSITE: 'CREW',
  },
  {
    DETECTION_TYPE: 'Load Side Voltage',
    TIMESTAMP: '2020-03-01 01:12:23',
    SERVICE_ORDER: '12345-S1',
    ESIID: '100888223412',
    METER_NUM: '321093',
    SUSPECT_NAME: 'Lisa Ann',
    CONFIDENCE: '92',
    CREW_ONSITE: 'CREW',
  },
  {
    DETECTION_TYPE: 'Disconnect Tamper',
    TIMESTAMP: '2020-03-02 09:32:22',
    SERVICE_ORDER: '12345-S1',
    ESIID: '100888212339',
    METER_NUM: '738282',
    SUSPECT_NAME: 'David Brent',
    CONFIDENCE: '96',
    CREW_ONSITE: 'CREW',
  },
  {
    DETECTION_TYPE: 'Disconnect Tamper',
    TIMESTAMP: '2020-03-04 08:44:22',
    SERVICE_ORDER: '12345-S1',
    ESIID: '100888219987',
    METER_NUM: '985632',
    SUSPECT_NAME: 'Michael Keaton',
    CONFIDENCE: '94',
    CREW_ONSITE: 'CREW',
  },
];

@Component({
  selector: 'app-suspect-list-details',
  templateUrl: './suspect-list-details.component.html',
  styles: [],
})
export class SuspectListDetailsComponent implements OnInit {
  displayedColumns: string[] = [
    'detect-type',
    'timestamp',
    'service-order',
    'esiid',
    'meter-num',
    'confidence-level',
    'suspect-name',
  ];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  readonly formControl: AbstractControl;

  constructor(formBuilder: FormBuilder) {
    this.dataSource.filterPredicate = ((data, filter) => {
      console.log(data, filter);
      const a = !filter.ESIID || data.ESIID.toLowerCase().includes(filter.ESIID);
      const b = !filter.DETECTION_TYPE || data.DETECTION_TYPE.toLowerCase().includes(filter.DETECTION_TYPE);
      const c = !filter.TIMESTAMP || data.TIMESTAMP === filter.TIMESTAMP;
      return a && b && c;
    }) as (PeriodicElement, string) => boolean;

    this.formControl = formBuilder.group({
      DETECTION_TYPE: '',
      ESIID: '',
      TIMESTAMP: '',
    });
    this.formControl.valueChanges.subscribe((value) => {
      const filter = {
        ...value,
        DETECTION_TYPE: value.DETECTION_TYPE.trim().toLowerCase(),
      } as string;
      console.log(filter, value);
      
      this.dataSource.filter = filter;
    });
  }

  ngOnInit(): void {}
}
