import { Component, OnInit } from '@angular/core';
import { ChartOptions } from '../../shared/chartOptions';

@Component({
  selector: 'app-detection-comparison',
  templateUrl: './detection-comparison.component.html',
})
export class DetectionComparisonComponent implements OnInit {
  public detectionMethodChartOptions: Partial<ChartOptions>;
  public diversionDispositionChartOptions: Partial<ChartOptions>;
  constructor() {
    this.getDataForDetectionMethodByMonthChart();
    this.getDataForDispositionByMonthChart();
  }

  ngOnInit(): void {}

  getDataForDetectionMethodByMonthChart(): void {
    this.detectionMethodChartOptions = {
      series: [
        {
          name: 'No Read Automation',
          data: [28, 29, 33, 36, 32, 32, 33, 43, 32, 11, 23, 32],
        },
        {
          name: 'Tamper',
          data: [12, 11, 14, 18, 17, 13, 13, 28, 29, 33, 36, 32],
        },
        {
          name: 'Disconnect',
          data: [18, 19, 23, 26, 42, 52, 23, 12, 11, 14, 18, 17],
        },
        {
          name: 'Load Side Volatage',
          data: [15, 19, 13, 58, 27, 33, 43, 17, 13, 13, 28, 29],
        },
        {
          name: 'Total',
          data: [15, 19, 13, 58, 17, 13, 13, 28, 29, 27, 33, 43],
        },
      ],
      chart: {
        height: 350,
        type: 'line',
        dropShadow: {
          enabled: true,
          color: '#000',
          top: 18,
          left: 7,
          blur: 10,
          opacity: 0.2,
        },
        toolbar: {
          show: false,
        },
      },
      // colors: ['#77B6EA', '#545454'],
      dataLabels: {
        enabled: true,
      },
      stroke: {
        curve: 'smooth',
      },
      grid: {
        show: true
        // borderColor: '#e7e7e7',
        // row: {
        //   colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
        //   opacity: 0.5,
        // },
      },
      theme: {
        mode: 'light',
        palette: 'palette5',
      },
      markers: {
        size: 1,
      },
      xaxis: {
        categories: [
          'Oct-19',
          'Nov-19',
          'Dec-19',
          'Jan-20',
          'Feb-20',
          'Mar-20',
          'Apr-20',
          'May-20',
          'Jun-20',
          'Jul-20',
          'Aug-20',
          'Sep-20',
        ],
        title: {
          text: '',
        },
      },
      yaxis: {
        title: {
          text: '',
        },
        min: 5,
        max: 60,
      },
      legend: {
        position: 'top',
        horizontalAlign: 'center',
        // floating: true,
        // offsetY: -25,
        // offsetX: -5,
      },
    };
  }

  getDataForDispositionByMonthChart(): void {
    this.diversionDispositionChartOptions = {
      series: [
        {
          name: 'Clean',
          data: [28, 29, 33, 36, 32, 32, 33, 43, 32, 11, 23, 32],
        },
        {
          name: 'Review',
          data: [12, 11, 14, 18, 17, 13, 13, 28, 29, 33, 36, 32],
        },
        {
          name: 'Meter Resolution',
          data: [18, 19, 23, 26, 42, 52, 23, 12, 11, 14, 18, 17],
        },
        {
          name: 'Tamper',
          data: [15, 19, 13, 58, 27, 33, 43, 17, 13, 13, 28, 29],
        },
        {
          name: 'Diversion',
          data: [26, 42, 52, 23, 12, 32, 33, 43, 32, 11, 23, 0],
        },
      ],
      chart: {
        height: 350,
        type: 'bar',
        stacked: true,
        toolbar: {
          show: false,
        },
      },
      // colors: ['#77B6EA', '#545454'],
      dataLabels: {
        enabled: true,
      },
      stroke: {
        curve: 'smooth',
      },
      theme: {
        // mode: 'light',
        palette: 'palette7',
      },
      // grid: {
      //   borderColor: '#e7e7e7',
      //   row: {
      //     colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
      //     opacity: 0.5,
      //   },
      // },
      markers: {
        size: 1,
      },
      xaxis: {
        categories: [
          'Oct-19',
          'Nov-19',
          'Dec-19',
          'Jan-20',
          'Feb-20',
          'Mar-20',
          'Apr-20',
          'May-20',
          'Jun-20',
          'Jul-20',
          'Aug-20',
          'Sep-20',
        ],
        title: {
          text: '',
        },
      },
      yaxis: {
        title: {
          text: '',
        },
      },
      legend: {
        position: 'top',
        horizontalAlign: 'center',
        // floating: true,
        // offsetY: -25,
        // offsetX: -5,
      },
    };
  }
}
