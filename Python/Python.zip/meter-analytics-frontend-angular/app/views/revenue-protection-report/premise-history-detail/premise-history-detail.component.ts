import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { ChartOptions } from '../../shared/chartOptions';

export interface PeriodicElement {
  EXCEPTION: string;
  TIMESTAMP: string;
  EXCEPTION_FLAG: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    EXCEPTION: 'Power Outage Notification',
    TIMESTAMP: '2020-02-01 08:44:22',
    EXCEPTION_FLAG: 'Exception',
  },
  {
    EXCEPTION: 'Power Restore Notification',
    TIMESTAMP: '2020-02-02 18:44:12',
    EXCEPTION_FLAG: 'Exception',
  },
  {
    EXCEPTION: 'Tamper Alert',
    TIMESTAMP: '2020-02-02 03:23:41',
    EXCEPTION_FLAG: 'Exception',
  },
  {
    EXCEPTION: 'Tamper Alert',
    TIMESTAMP: '2020-02-03 09:32:32',
    EXCEPTION_FLAG: 'Exception',
  },
  {
    EXCEPTION: 'Tamper Alert',
    TIMESTAMP: '2020-02-04 06:44:02',
    EXCEPTION_FLAG: 'Exception',
  },
  {
    EXCEPTION: 'Power Restore Notification',
    TIMESTAMP: '2020-02-05 03:11:08',
    EXCEPTION_FLAG: 'Exception',
  },
  {
    EXCEPTION: 'Tamper Alert',
    TIMESTAMP: '2020-02-11 05:54:22',
    EXCEPTION_FLAG: 'Exception',
  },
  {
    EXCEPTION: 'Power Outage Notification',
    TIMESTAMP: '2020-02-21 08:24:55',
    EXCEPTION_FLAG: 'Exception',
  },
  {
    EXCEPTION: 'Power Outage Notification',
    TIMESTAMP: '2020-02-24 02:44:22',
    EXCEPTION_FLAG: 'Exception',
  },
];

export interface ICustomerDetails {
  SDPID: string;
  CUSTID: string;
  CUST_NAME: string;
  CUST_ADDRESS: string;
  METERID: string;
  DEVICE_TYPE: string;
  CUST_TYPE: string;
}

const CUSTOMER_DETAILS_DATA: ICustomerDetails[] = [
  {
    SDPID: '100888216548',
    CUSTID: '62321345',
    CUST_NAME: 'Joshy Joseph',
    CUST_ADDRESS: 'Houston',
    METERID: '325124',
    DEVICE_TYPE: 'Tamper',
    CUST_TYPE: 'NA',
  },
  {
    SDPID: '100888212319',
    CUSTID: '34509890',
    CUST_NAME: 'Angela White',
    CUST_ADDRESS: 'Houston',
    METERID: '948339',
    DEVICE_TYPE: 'Tamper',
    CUST_TYPE: 'NA',
  },
  {
    SDPID: '100888212342',
    CUSTID: '34356009',
    CUST_NAME: 'Joseph',
    CUST_ADDRESS: 'Houston',
    METERID: '433278',
    DEVICE_TYPE: 'Tamper',
    CUST_TYPE: 'NA',
  },
  {
    SDPID: '100888212342',
    CUSTID: '54567864',
    CUST_NAME: 'Nancy Joseph',
    CUST_ADDRESS: 'WA',
    METERID: '435784',
    DEVICE_TYPE: 'Tamper',
    CUST_TYPE: 'NA',
  },
  {
    SDPID: '100888212339',
    CUSTID: '87756432',
    CUST_NAME: 'David Brent',
    CUST_ADDRESS: 'LA',
    METERID: '738282',
    DEVICE_TYPE: 'Tamper',
    CUST_TYPE: 'NA',
  },
];
@Component({
  selector: 'app-premise-history-detail',
  templateUrl: './premise-history-detail.component.html',
  styles: [],
})
export class PremiseHistoryDetailComponent implements OnInit, AfterViewInit {
  @ViewChild('MatPaginatorAMI') paginatorAMI: MatPaginator;
  @ViewChild('MatPaginatorCustomer') paginatorCustomer: MatPaginator;
  
  selectedStatus: string;
  selectedTypeCode: string[];
  selectedSDPID: string[];

  displayedColumns: string[] = [
    'select',
    'exception',
    'timestamp',
    'exception-flag',
  ];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  selection = new SelectionModel<PeriodicElement>(true, []);

  displayedColumnsForCustomerDetails: string[] = [
    'sdpid',
    'custid',
    'cust_name',
    'cust_address',
    'meterid',
    'device_type',
    'cust_type',
  ];
  dataSourceForCustomerDetails = new MatTableDataSource<ICustomerDetails>(
    CUSTOMER_DETAILS_DATA
  );
  // selectionForCustomerDetails = new SelectionModel<PeriodicElement>(true, []);

  public usageHistoryChartOptions: Partial<ChartOptions>;

  constructor() {}

  ngOnInit(): void {
    this.getDataForUsageHistoryChart();
  }
  ngAfterViewInit(): void {
    // this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginatorAMI;
    this.dataSourceForCustomerDetails.paginator = this.paginatorCustomer;
    // this.table.dataSource = this.dataSource;
  }

  getDataForUsageHistoryChart(): void {
    this.usageHistoryChartOptions = {
      series: [
        {
          name: 'Usage',
          data: [28, 29, 33, 36, 32, 32, 33],
        },
        {
          name: 'Average Usage',
          data: [12, 11, 14, 18, 17, 13, 13],
        },
      ],
      chart: {
        height: 350,
        type: 'line',
        dropShadow: {
          enabled: true,
          color: '#000',
          top: 18,
          left: 7,
          blur: 10,
          opacity: 0.2,
        },
        toolbar: {
          show: false,
        },
      },
      // colors: ['#77B6EA', '#545454'],
      dataLabels: {
        enabled: true,
      },
      stroke: {
        curve: 'smooth',
      },
      xaxis: {
        categories: [
          '7/6/2020',
          '7/7/2020',
          '7/8/2020',
          '7/12/2020',
          '7/13/2020',
          '7/14/2020',
          '7/15/2020',
        ],
        title: {
          text: '',
        },
      },
      yaxis: {
        title: {
          text: '',
        },
        min: 5,
        max: 60,
      },
      legend: {
        position: 'top',
        horizontalAlign: 'center',
        // floating: true,
        // offsetY: -25,
        // offsetX: -5,
      },
    };
  }
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.data.forEach((row) => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: PeriodicElement): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${
      this.selection.isSelected(row) ? 'deselect' : 'select'
    } row ${row}`;
  }
}
