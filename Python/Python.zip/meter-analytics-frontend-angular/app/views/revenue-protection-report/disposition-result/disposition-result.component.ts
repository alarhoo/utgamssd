import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';

export interface PeriodicElement {
  SDPID: string;
  METERID: string;
  ACC_NUM: string;
  CREATION_GROUP: string;
  DISP_GROUP: string;
  DISP_CATEGORY: string;
  DESC: string;
  DIVERSIONED: string;
  NOTES: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    SDPID: '10090323843432',
    METERID: '123453',
    ACC_NUM: '01123213',
    CREATION_GROUP: 'Disconnect',
    DISP_GROUP: 'Clean',
    DISP_CATEGORY: 'Clean',
    DESC: 'Found and Left',
    DIVERSIONED: 'N',
    NOTES: 'Notes',
  },
  {
    SDPID: '10090323843258',
    METERID: '439247',
    ACC_NUM: '536342',
    CREATION_GROUP: 'Disconnect',
    DISP_GROUP: 'Diversion',
    DISP_CATEGORY: 'Diversion',
    DESC: 'Found Diversion',
    DIVERSIONED: 'Y',
    NOTES: 'Notes',
  },
  {
    SDPID: '10090323736473',
    METERID: '546833',
    ACC_NUM: '01987313',
    CREATION_GROUP: 'Disconnect',
    DISP_GROUP: 'Clean',
    DISP_CATEGORY: 'Clean',
    DESC: 'Found and Left',
    DIVERSIONED: 'N',
    NOTES: 'Notes',
  },
  {
    SDPID: '10090323854398',
    METERID: '765499',
    ACC_NUM: '01129987',
    CREATION_GROUP: 'Disconnect',
    DISP_GROUP: 'Meter Resolution',
    DISP_CATEGORY: 'Meter Resolution',
    DESC: 'Issue with the Meter',
    DIVERSIONED: 'N',
    NOTES: 'Notes',
  },
  {
    SDPID: '10090323843432',
    METERID: '454342',
    ACC_NUM: '01127865',
    CREATION_GROUP: 'Disconnect',
    DISP_GROUP: 'Diversion',
    DISP_CATEGORY: 'Diversion',
    DESC: 'Found Diversion',
    DIVERSIONED: 'Y',
    NOTES: 'Notes',
  },
  {
    SDPID: '10090323854398',
    METERID: '765499',
    ACC_NUM: '01129987',
    CREATION_GROUP: 'Disconnect',
    DISP_GROUP: 'Meter Resolution',
    DISP_CATEGORY: 'Meter Resolution',
    DESC: 'Issue with the Meter',
    DIVERSIONED: 'N',
    NOTES: 'Notes',
  },
  {
    SDPID: '10094783643432',
    METERID: '451232',
    ACC_NUM: '02211865',
    CREATION_GROUP: 'Disconnect',
    DISP_GROUP: 'Diversion',
    DISP_CATEGORY: 'Diversion',
    DESC: 'Found Diversion',
    DIVERSIONED: 'Y',
    NOTES: 'Notes',
  },
  {
    SDPID: '10090389764398',
    METERID: '124321',
    ACC_NUM: '01190987',
    CREATION_GROUP: 'Disconnect',
    DISP_GROUP: 'Meter Resolution',
    DISP_CATEGORY: 'Meter Resolution',
    DESC: 'Issue with the Meter',
    DIVERSIONED: 'N',
    NOTES: 'Notes',
  },
  {
    SDPID: '10076753843432',
    METERID: '898788',
    ACC_NUM: '01765465',
    CREATION_GROUP: 'Disconnect',
    DISP_GROUP: 'Diversion',
    DISP_CATEGORY: 'Diversion',
    DESC: 'Found Diversion',
    DIVERSIONED: 'Y',
    NOTES: 'Notes',
  },
];

@Component({
  selector: 'app-disposition-result',
  templateUrl: './disposition-result.component.html',
  styles: [],
})
export class DispositionResultComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  selectedCreationGroup: string = 'disconnect';
  selectedDispositionGroup: string[];
  selectedDispositionCategory: string[];
  selectedFoundDiversioned: string[];
  filterValues = {};
  filterSelectObj = [];
  modelCreationGroup: string = 'Clean';

  displayedColumns: string[] = [
    'select',
    'sdpid',
    'meterid',
    'account-number',
    // 'creation-group',
    'disp-group',
    'disp-category',
    'description',
    'diversioned',
    'notes',
  ];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  selection = new SelectionModel<PeriodicElement>(true, []);

  constructor() {}

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    // this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.dataSource.data = ELEMENT_DATA;
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.data.forEach((row) => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: PeriodicElement): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${
      this.selection.isSelected(row) ? 'deselect' : 'select'
    } row ${row}`;
  }
}
