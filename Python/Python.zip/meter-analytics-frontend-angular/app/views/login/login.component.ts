import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  constructor(private router: Router) {}

  signIn(): void {
    // console.log(`User logger in`);
    this.router.navigateByUrl('MeterReadSummary');
  }

  ngOnInit(): void {}
}
