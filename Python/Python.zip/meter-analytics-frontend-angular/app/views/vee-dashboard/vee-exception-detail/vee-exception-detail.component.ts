import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import {
  VeeExceptionDetailDataSource,
  VeeExceptionDetailItem,
} from './vee-exception-detail-datasource';

@Component({
  selector: 'app-vee-exception-detail',
  templateUrl: './vee-exception-detail.component.html',
  styles: [],
})
export class VeeExceptionDetailComponent implements AfterViewInit, OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatTable) table: MatTable<VeeExceptionDetailItem>;
  dataSource: VeeExceptionDetailDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = [
    'id',
    'except_date',
    'except_time',
    'except_type',
    'status',
    'sdp_id',
    'meter_id',
  ];

  ngOnInit(): void {
    this.dataSource = new VeeExceptionDetailDataSource();
    console.log(this.dataSource);
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }
}
