import { Component, OnInit, ViewChild } from '@angular/core';
import { ChartOptions } from '../../shared/chartOptions';
@Component({
  selector: 'app-vee-exception-rank',
  templateUrl: './vee-exception-rank.component.html',
})
export class VeeExceptionRankComponent implements OnInit {
  public chartOptions: Partial<ChartOptions>;
  constructor() {
    this.getDataForVeeExceptionRankChart();
  }

  ngOnInit(): void {}

  getDataForVeeExceptionRankChart(): void {
    this.chartOptions = {
      series: [
        {
          name: 'Exceptions Count',
          data: [40, 230, 348, 470, 540, 680, 790, 810, 1200],
        },
      ],
      chart: {
        type: 'bar',
        height: 350,
        toolbar: {
          show: false,
        },
      },
      plotOptions: {
        bar: {
          horizontal: true,
        },
      },
      dataLabels: {
        enabled: true,
      },
      xaxis: {
        categories: [
          'Invalid Work Status Notification Request',
          'Export Failed',
          'Device Not Found Exception',
          'Invalid Request',
          'Device Not Installed Exception',
          'Configuration Error',
          'Unexpected Processing Error',
          'Invalid Process Error',
          'Missing Intervals'
        ],
      },
    };
  }
}
