import { Component, OnInit } from '@angular/core';
import { MatButtonToggleGroup } from '@angular/material/button-toggle';

@Component({
  selector: 'app-vee-dashboard',
  templateUrl: './vee-dashboard.component.html',
  styles: [],
})
export class VeeDashboardComponent implements OnInit {
  displayedColumns: string[] = [];
  dataSource = ELEMENT_DATA;

  tables = [0];

  constructor() {
    // The first two columns should be position and name; the last two columns: weight, symbol
    this.displayedColumns[0] = 'position';
    this.displayedColumns[1] = 'name';
    this.displayedColumns[2] = 'weight';
    this.displayedColumns[3] = 'position1';
    this.displayedColumns[4] = 'name1';
    this.displayedColumns[5] = 'weight1';
    this.displayedColumns[6] = 'symbol';
  }

  /** Whether the button toggle group contains the id as an active value. */
  // tslint:disable-next-line: typedef
  isSticky(buttonToggleGroup: MatButtonToggleGroup, id: string) {
    return (buttonToggleGroup.value || []).indexOf(id) !== -1;
  }

  ngOnInit(): void {}
}

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  name1: string;
  position1: number;
  weight1: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    position: 1,
    name: 'Hydrogen',
    weight: 1.0079,
    position1: 1,
    name1: 'Hydrogen',
    weight1: 1.0079,
    symbol: 'H',
  },
  {
    position: 1,
    name: 'Hydrogen',
    weight: 1.0079,
    position1: 1,
    name1: 'Hydrogen',
    weight1: 1.0079,
    symbol: 'H',
  },
  {
    position: 1,
    name: 'Hydrogen',
    weight: 1.0079,
    position1: 1,
    name1: 'Hydrogen',
    weight1: 1.0079,
    symbol: 'H',
  },
  {
    position: 1,
    name: 'Hydrogen',
    weight: 1.0079,
    position1: 1,
    name1: 'Hydrogen',
    weight1: 1.0079,
    symbol: 'H',
  },
  {
    position: 1,
    name: 'Hydrogen',
    weight: 1.0079,
    position1: 1,
    name1: 'Hydrogen',
    weight1: 1.0079,
    symbol: 'H',
  },
  {
    position: 1,
    name: 'Hydrogen',
    weight: 1.0079,
    position1: 1,
    name1: 'Hydrogen',
    weight1: 1.0079,
    symbol: 'H',
  },
  {
    position: 1,
    name: 'Hydrogen',
    weight: 1.0079,
    position1: 1,
    name1: 'Hydrogen',
    weight1: 1.0079,
    symbol: 'H',
  },
  {
    position: 1,
    name: 'Hydrogen',
    weight: 1.0079,
    position1: 1,
    name1: 'Hydrogen',
    weight1: 1.0079,
    symbol: 'H',
  },
  {
    position: 1,
    name: 'Hydrogen',
    weight: 1.0079,
    position1: 1,
    name1: 'Hydrogen',
    weight1: 1.0079,
    symbol: 'H',
  },
  {
    position: 1,
    name: 'Hydrogen',
    weight: 1.0079,
    position1: 1,
    name1: 'Hydrogen',
    weight1: 1.0079,
    symbol: 'H',
  },
];
