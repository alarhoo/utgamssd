import { Component, OnInit, ViewChild } from '@angular/core';
import { ChartOptions } from '../../shared/chartOptions';
@Component({
  selector: 'app-vee-exception-trend',
  templateUrl: './vee-exception-trend.component.html',
  styles: [],
})
export class VeeExceptionTrendComponent implements OnInit {
  // @ViewChild('chart') chart!: ChartComponent;
  public chartOptions: Partial<ChartOptions>;
  constructor() {
    this.getDataForVeeExceptionTrendChart();
  }

  ngOnInit(): void {}

  getDataForVeeExceptionTrendChart(): void {
    this.chartOptions = {
      series: [
        {
          name: 'Missing Intervals',
          data: [28, 29, 33, 36, 32, 32, 33],
        },
        {
          name: 'Meter Update Exception',
          data: [12, 11, 14, 18, 17, 13, 13],
        },
        {
          name: 'Device Not Installed Exception',
          data: [18, 19, 23, 26, 42, 52, 23],
        },
        {
          name: 'Device Not Found Exception',
          data: [15, 19, 13, 58, 27, 33, 43],
        },
      ],
      chart: {
        height: 350,
        type: 'line',
        dropShadow: {
          enabled: true,
          color: '#000',
          top: 18,
          left: 7,
          blur: 10,
          opacity: 0.2,
        },
        toolbar: {
          show: false,
        },
      },
      // colors: ['#77B6EA', '#545454'],
      dataLabels: {
        enabled: true,
      },
      stroke: {
        curve: 'smooth',
      },
      title: {
        text: 'Average High & Low Temperature',
        align: 'left',
      },
      grid: {
        borderColor: '#e7e7e7',
        row: {
          colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
          opacity: 0.5,
        },
      },
      markers: {
        size: 1,
      },
      xaxis: {
        categories: ['7/6/2020', '7/7/2020', '7/8/2020', '7/12/2020', '7/13/2020', '7/14/2020', '7/15/2020'],
        title: {
          text: '',
        },
      },
      yaxis: {
        title: {
          text: '',
        },
        min: 5,
        max: 60,
      },
      legend: {
        position: 'top',
        horizontalAlign: 'center',
        // floating: true,
        // offsetY: -25,
        // offsetX: -5,
      },
    };
  }
}
