import {
  AfterViewInit,
  Component,
  OnInit,
  ViewChild,
  Inject,
  Input,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatDialog } from '@angular/material/dialog';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { ChartComponent } from 'ng-apexcharts';
import { ChartOptions } from '../../shared/chartOptions';
import { RestApiService } from 'src/app/services/rest-api.service';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

// Sno	Meter ID	Exception Case	SDP 	Installation Date
export interface MdReconDetailItem {
  meterid: string;
  position: number;
  expceptionCase: string;
  sdp: string;
  installationDate: string;
}

const ELEMENT_DATA: MdReconDetailItem[] = [
  {
    position: 1,
    meterid: '10931198',
    expceptionCase: 'Yes',
    sdp: '1245432',
    installationDate: '01/01/2021',
  },
  {
    position: 2,
    meterid: '10931197',
    expceptionCase: 'No',
    sdp: '1245433',
    installationDate: '01/01/2021',
  },
  {
    position: 3,
    meterid: '10931199',
    expceptionCase: 'No',
    sdp: '1245434',
    installationDate: '01/01/2021',
  },
  {
    position: 4,
    meterid: '10931194',
    expceptionCase: 'No',
    sdp: '1245435',
    installationDate: '01/01/2021',
  },
  {
    position: 5,
    meterid: '10931193',
    expceptionCase: 'Yes',
    sdp: '1245436',
    installationDate: '01/01/2021',
  },
  {
    position: 6,
    meterid: '10931192',
    expceptionCase: 'Yes',
    sdp: '1245437',
    installationDate: '01/01/2021',
  },
  {
    position: 7,
    meterid: '10931191',
    expceptionCase: 'Yes',
    sdp: '1245438',
    installationDate: '01/01/2021',
  },
  {
    position: 8,
    meterid: '10931148',
    expceptionCase: 'No',
    sdp: '12454329',
    installationDate: '01/01/2021',
  },
  {
    position: 9,
    meterid: '10931168',
    expceptionCase: 'No',
    sdp: '12454321',
    installationDate: '01/01/2021',
  },
  {
    position: 10,
    meterid: '10931598',
    expceptionCase: 'No',
    sdp: '12454320',
    installationDate: '01/01/2021',
  },
];

@Component({
  selector: 'app-md-recon-summary',
  templateUrl: './md-recon-summary.component.html',
  styles: [''],
})
export class MdReconSummaryComponent
  implements OnInit, AfterViewInit, OnChanges {
  @ViewChild('chartForMDReconSummary') chartForMDReconSummary: ChartComponent;
  public chartOptionsForMDReconSummary: Partial<ChartOptions>;
  @Input() public selectedMeter;

  // @ViewChild(MatTable) table: MatTable<UserData>;
  showDetailMasterDataTable = false;
  displayedColumns: string[] = [
    'select',
    'position',
    'expceptionCase',
    'sdp',
    'installationDate',
    // 'ping',
    // 'serviceOrder',
    // 'ticket',
  ];

  // dataSource = masterdata;
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  selection = new SelectionModel<MdReconDetailItem>(true, []);

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(public dialog: MatDialog, private apiService: RestApiService) {
    // this.getDataForMeterSummaryChart();
    // this.dataSource = new MatTableDataSource(masterdata);
  }

  ngOnInit(): void {}
  ngOnChanges(changes: SimpleChanges): void {
    if (changes.selectedMeter.currentValue) {
      this.chartOptionsForMDReconSummary.series = [
        {
          name: 'Missing Meters',
          data: [1, 0, 1],
        },
      ];
    } else {
      this.getDataForMeterSummaryChart();
    }
  }

  ngAfterViewInit(): void {
    // this.dataSource.paginator = this.paginator;
    // this.dataSource.sort = this.sort;    
  }

  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    // this.dataSource.filter = filterValue.trim().toLowerCase();

    // if (this.dataSource.paginator) {
    //   this.dataSource.paginator.firstPage();
    // }
  }
  getDataForMeterSummaryChart(): void {
    let matchingMeters;
    this.chartOptionsForMDReconSummary = {
      series: [
        {
          name: 'Missing Meters',
          data: [],
        },
      ],
      chart: {
        type: 'bar',
        height: 200,
        toolbar: {
          show: false,
        },
        events: {
          dataPointSelection: (event, chartContext, config) => {
            if (config.dataPointIndex === 0) {
              this.showDetailTableForMasterData('MDM');
            } else if (config.dataPointIndex === 1) {
              this.showDetailTableForMasterData('HES');
            } else {
              this.showDetailTableForMasterData('SAP');
            }
          },
        },
      },
      plotOptions: {
        bar: {
          horizontal: true,
          distributed: true,
        },
      },
      dataLabels: {
        enabled: true,
      },
      noData: {
        text: 'Loading...',
      },
      legend: {
        position: 'top',
        horizontalAlign: 'center',
      },
      xaxis: {
        categories: [
          'Missing Meters MDM',
          'Missing Meters HES',
          'Missing Meters SAP',
        ],
      },
      theme: {
        mode: 'light',
        palette: 'palette6',
      },
    };

    this.apiService.getDataFromApi('apiForMasterDataSummary').subscribe({
      next: (response) => {
        const summaryItems = response.filter((el) => el.METRICS_ID === 'KPI');
        summaryItems.forEach((element) => {
          if (element.STATUS === 'MATCHING_METERS') {
            matchingMeters = element.COUNT;
          } else {
            this.chartOptionsForMDReconSummary.series[0].data.push(
              element.COUNT
            );
            // this.chartOptionsForMDReconSummary.xaxis.categories[0].push();
          }
          setTimeout(() => {
            window.dispatchEvent(new Event('resize'));
            this.chartForMDReconSummary.toggleSeries('Missing Meters')
          }, 1000);
        });
      },
    });
  }

  showDetailTableForMasterData(serviceName): void {
    this.dialog.open(MdReconDetailDialogComponent, {
      maxWidth: '90vw',
      maxHeight: '90vh',
      height: '100%',
      width: '100%',
      data: { serviceName },
    });
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 1000);
  }

  closeColumn(): void {
    this.showDetailMasterDataTable = false;
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 1000);
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected(): any {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle(): void {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.data.forEach((row) => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: MdReconDetailItem): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.position + 1
    }`;
  }
}

@Component({
  selector: 'app-mdrecon-detail-dialog',
  templateUrl: 'mdrecon-detail.dialog.html',
})
export class MdReconDetailDialogComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatTable) table: MatTable<MdReconDetailItem>;

  ELEMENT_DATA: any[] = [];
  displayedColumns: string[] = [
    'select',
    'METER_NUMBER',
    'DEVICE_NUMBER',
    'SDP',
    'INSTALLATION_DATE',
    'SERVICE_CENTER',
  ];

  dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
  selection = new SelectionModel<any>(true, []);
  serviceName = 'HES';

  constructor(
    private apiService: RestApiService,
    @Inject(MAT_DIALOG_DATA) public data: { serviceName: string }
  ) {
    this.serviceName = data.serviceName;
  }

  ngOnInit(): void {
    this.getDataForDetailTable();
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }

  closeColumn(): void {
    // this.showDetailConnectionTable = false;
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 1000);
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected(): any {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle(): void {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.data.forEach((row) => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: any): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.METER_NUMBER
    }`;
  }

  getDataForDetailTable(): void {
    const apiName =
      this.serviceName === 'SAP'
        ? 'apiForDetailMissingMeterSap'
        : this.serviceName === 'MDM'
        ? 'apiForDetailMissingMeterMdm'
        : 'apiForDetailMissingMeterHes';
    this.apiService.getDataFromApi(apiName).subscribe({
      next: (detailTable) => {
        this.dataSource.data = detailTable;
      },
    });
  }

  serviceOrderHandler(): void {
    window.open(
      'https://utg-webdisp.utegration.com:44304/sap/bc/gui/sap/its/webgui/?~transaction=iw73%20AUFNR-LOW=91234911;',
      '_blank'
    );
  }
}
