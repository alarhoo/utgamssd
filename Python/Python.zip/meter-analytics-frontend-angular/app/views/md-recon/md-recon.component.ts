import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { LoaderService } from 'src/app/services/loader.service';
import { RestApiService } from 'src/app/services/rest-api.service';

@Component({
  selector: 'app-md-recon',
  templateUrl: './md-recon.component.html',
  styles: [
    `
      .input-form {
        min-width: 150px;
        max-width: 500px;
        width: 100%;
      }

      .input-full-width {
        width: 100%;
      }
    `,
  ],
})
export class MdReconComponent implements OnInit {
  myControl = new FormControl();
  options: string[] = ['All'];
  isViewable: boolean;
  sSelectedMeter: string;
  constructor(
    public loaderService: LoaderService,
    public apiService: RestApiService
  ) {
    this.apiService.getDataFromApi('apiForTotalMeters').subscribe({
      next: (response) => {
        response.forEach((el) => {
          this.options.push(el.METER_ID);
        });
        // this.options.unshift('All');
        setTimeout(() => {
          window.dispatchEvent(new Event('resize'));
        }, 1000);
      },
    });
  }

  filteredOptions: Observable<string[]>;

  ngOnInit(): void {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map((value) => this._filter(value))
    );
    this.isViewable = false;
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(
      (option) => option.toLowerCase().indexOf(filterValue) === 0
    );
  }

  onSelectMeter($event): void {
    this.loaderService.isLoading.next(true);
    setTimeout(() => {
      this.loaderService.isLoading.next(false);
      this.sSelectedMeter =
        $event.option.value === 'All' ? undefined : $event.option.value;
    }, 2000);
  }
}
