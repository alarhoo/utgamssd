import {
  Component,
  OnInit,
  ViewChild,
  AfterViewInit,
  Inject,
  Input,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { TitleCasePipe } from '@angular/common';
import { RestApiService } from 'src/app/services/rest-api.service';
import { SplitComponent, SplitAreaDirective } from 'angular-split';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SelectionModel } from '@angular/cdk/collections';

import { groupBy } from '../../../../../node_modules/lodash/fp/groupBy';
import _ from 'lodash';
import {
  AttribDetailDataSource,
  AttribDetailItem,
} from './attrib-detail-datasource';
import { ChartComponent } from 'ng-apexcharts';
import { ChartOptions } from '../../shared/chartOptions';

@Component({
  selector: 'app-attr-charts',
  templateUrl: './attr-charts.component.html',
  styles: [''],
})
export class AttrChartsComponent implements OnInit, OnChanges {
  @ViewChild('chartForAttributeStatus') chartForAttributeStatus: ChartComponent;
  public chartOptions: Partial<ChartOptions>;
  categories: string[][];
  series: { name: string; data: number[] }[];
  chartData: {
    title: { text: string };
    xaxis: { categories: string[] };
    series: { name: string; data: number[] }[];
  }[];

  showDetailTableForAttributes = false;
  @Input() public selectedMeter;

  constructor(
    private apiService: RestApiService,
    private titlecasePipe: TitleCasePipe,
    public dialog: MatDialog
  ) {}

  ngOnInit(): void {
    // this.initChart();
    // this.getChartData();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.selectedMeter.currentValue) {
      this.chartOptions.series = [
        {
          name: 'Matching',
          data: [1, 0, 1, 1, 0, 0, 1],
        },
        {
          name: 'Mismatch',
          data: [0, 1, 0, 0, 1, 1, 0],
        },
      ];
    } else {
      this.initChart();
    }
  }

  getChartData(): void {
    this.apiService.getDataFromApi('apiForMasterDataSummary').subscribe({
      next: (resp) => {
        let attribData = resp.filter((el) => {
          return (
            el.METRICS_ID !== 'KPI' && el.METRICS_ID !== 'LOAD_POWER_STATUS'
          );
        });
        // console.log(attribData);
        attribData = _.groupBy(attribData, 'METRICS_ID');
        // console.log(attribData, JSON.stringify(attribData));
        for (const [key, value] of Object.entries(attribData)) {
          const tempData = [];
          const tempLabel = [];
          attribData[key].forEach((e) => {
            tempData.push(e.COUNT);
            tempLabel.push(
              this.titlecasePipe.transform(
                e.SUB_METRICS_ID.replace(/_/g, ' ') + ' ' + e.STATUS
              )
            );
          });
          this.chartData.push({
            series: [
              {
                name: key.toLocaleLowerCase(),
                data: tempData,
              },
            ],
            title: {
              text:
                key.charAt(0) +
                key.slice(1).toLowerCase().replace(/_/g, ' ') +
                ' Attributes',
            },
            xaxis: {
              categories: tempLabel,
            },
          });
          console.log(
            key.charAt(0) +
              key.slice(1).toLowerCase().replace(/_/g, ' ') +
              ' Attributes'
          );
          console.log(key, tempData, tempLabel);
        }
      },
    });
  }

  initChart(): void {
    this.chartOptions = {
      series: [
        {
          name: 'Matching',
          data: [],
        },
        {
          name: 'Mismatch',
          data: [],
        },
      ],
      chart: {
        type: 'bar',
        height: 310,
        stacked: true,
        // stackType: '100%',
        toolbar: {
          show: false,
        },
        events: {
          dataPointSelection: (event, chartContext, config) => {
            // console.log(event, chartContext, config);
            console.log(
              config.w.config.series[config.seriesIndex].name,
              ' ',
              config.w.config.xaxis.categories[config.dataPointIndex]
            );
            const attrName = config.w.config.xaxis.categories[
              config.dataPointIndex
            ].slice(0, -1);
            this.showDetailTableForAttribute(attrName);
          },
        },
      },
      plotOptions: {
        bar: {
          horizontal: true,
        },
      },
      noData: {
        text: 'Loading...',
      },
      dataLabels: {
        enabled: true,
        // style: {
        //   fontSize: '14px',
        //   fontFamily: 'Helvetica, Arial, sans-serif',
        //   fontWeight: 'bold',
        //   colors: ['#202020'],
        // },
      },
      xaxis: {
        categories: [
          'Rate Attributes',
          'Meter Attributes',
          'Account Attributes',
          'Profile Attributes',
          'Location Latitude Attributes',
          'Location Logitude Attributes',
          'Register Attributes',
        ],
      },
      legend: {
        position: 'top',
        horizontalAlign: 'center',
      },
    };

    this.apiService.getDataFromApi('apiForMasterDataSummary').subscribe({
      next: (resp) => {
        const attribData = resp.filter((el) => {
          return (
            el.METRICS_ID !== 'KPI' && el.METRICS_ID !== 'LOAD_POWER_STATUS'
          );
        });
        attribData.forEach((element) => {
          if (element.STATUS === 'MATCHING') {
            this.chartOptions.series[0].data.push(element.COUNT);
          } else {
            this.chartOptions.series[1].data.push(element.COUNT);
          }
        });
        setTimeout(() => {
          this.chartForAttributeStatus.toggleSeries('Matching');
          window.dispatchEvent(new Event('resize'));
        }, 1500);
      },
    });
  }

  showDetailTableForAttribute(attrName): void {
    this.dialog.open(AttribDetailDialogComponent, {
      maxWidth: '90vw',
      maxHeight: '90vh',
      height: '100%',
      width: '100%',
      data: { attrName },
    });
    this.showDetailTableForAttributes = true;
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 1000);
  }

  closeColumn(): void {
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 1000);
  }
}

@Component({
  selector: 'app-attrib-detail-dialog',
  templateUrl: 'attrib-detail.dialog.html',
})
export class AttribDetailDialogComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatTable) table: MatTable<AttribDetailItem>;
  displayedColumns = [
    'select',
    'meter_id',
    'attr_1_hes',
    'attr_1_mdm',
    'attr_1_sap',
    'attr_2_hes',
    'attr_2_mdm',
    'attr_2_sap',
    // 'sync',
    // 'serviceOrder',
    // 'ticket',
  ];
  attribDetailDatasource: AttribDetailDataSource;
  tableTitle = '';
  attrName = 'Rate';

  selection = new SelectionModel<AttribDetailItem>(true, []);

  constructor(@Inject(MAT_DIALOG_DATA) public data: { attrName: string }) {
    this.attrName = data.attrName;
  }

  ngOnInit(): void {
    this.attribDetailDatasource = new AttribDetailDataSource();
  }

  ngAfterViewInit(): void {
    this.attribDetailDatasource.sort = this.sort;
    this.attribDetailDatasource.paginator = this.paginator;
    this.table.dataSource = this.attribDetailDatasource;
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected(): any {
    const numSelected = this.selection.selected.length;
    const numRows = this.attribDetailDatasource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle(): void {
    this.isAllSelected()
      ? this.selection.clear()
      : this.attribDetailDatasource.data.forEach((row) =>
          this.selection.select(row)
        );
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: AttribDetailItem): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.id + 1
    }`;
  }

  serviceOrderHandler(): void {
    window.open(
      'https://utg-webdisp.utegration.com:44304/sap/bc/gui/sap/its/webgui/?~transaction=iw73%20AUFNR-LOW=91234911;',
      '_blank'
    );
  }
}
