import { DataSource } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { map } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';

// TODO: Replace this with your own data model type
export interface AttribDetailItem {
  id: number;
  attr_1_hes: string;
  attr_1_mdm: string;
  attr_1_sap: string;
  attr_2_hes: string;
  attr_2_mdm: string;
  attr_2_sap: string;
  meter_id: string;
}

// TODO: replace this with real data from your application
const EXAMPLE_DATA: AttribDetailItem[] = [
  {
    id: 1,
    attr_1_hes: 'On',
    attr_1_mdm: 'On',
    attr_1_sap: 'Off',
    attr_2_hes: 'On',
    attr_2_mdm: 'On',
    attr_2_sap: 'Off',
    meter_id: '10931198',
  },
  {
    id: 2,
    attr_1_hes: 'Off',
    attr_1_mdm: 'On',
    attr_1_sap: 'On',
    attr_2_hes: 'On',
    attr_2_mdm: 'On',
    attr_2_sap: 'Off',
    meter_id: '10931299',
  },
  {
    id: 3,
    attr_1_hes: 'On',
    attr_1_mdm: 'On',
    attr_1_sap: 'On',
    attr_2_hes: 'On',
    attr_2_mdm: 'On',
    attr_2_sap: 'Off',
    meter_id: '10931298',
  },
  {
    id: 1,
    attr_1_hes: 'On',
    attr_1_mdm: 'Off',
    attr_1_sap: 'Off',
    attr_2_hes: 'On',
    attr_2_mdm: 'On',
    attr_2_sap: 'Off',
    meter_id: '10931298',
  },
  {
    id: 1,
    attr_1_hes: 'On',
    attr_1_mdm: 'Off',
    attr_1_sap: 'Off',
    attr_2_hes: 'On',
    attr_2_mdm: 'On',
    attr_2_sap: 'Off',
    meter_id: '10931298',
  },
  {
    id: 1,
    attr_1_hes: 'On',
    attr_1_mdm: 'On',
    attr_1_sap: 'Off',
    attr_2_hes: 'On',
    attr_2_mdm: 'On',
    attr_2_sap: 'Off',
    meter_id: '10931298',
  },
  {
    id: 1,
    attr_1_hes: 'Off',
    attr_1_mdm: 'On',
    attr_1_sap: 'Off',
    attr_2_hes: 'On',
    attr_2_mdm: 'On',
    attr_2_sap: 'Off',
    meter_id: '10931298',
  },
  {
    id: 1,
    attr_1_hes: 'On',
    attr_1_mdm: 'On',
    attr_1_sap: 'Off',
    attr_2_hes: 'On',
    attr_2_mdm: 'Off',
    attr_2_sap: 'Off',
    meter_id: '10931298',
  },
  {
    id: 1,
    attr_1_hes: 'Off',
    attr_1_mdm: 'On',
    attr_1_sap: 'Off',
    attr_2_hes: 'On',
    attr_2_mdm: 'On',
    attr_2_sap: 'Off',
    meter_id: '10931298',
  },
  {
    id: 1,
    attr_1_hes: 'On',
    attr_1_mdm: 'Off',
    attr_1_sap: 'Off',
    attr_2_hes: 'On',
    attr_2_mdm: 'On',
    attr_2_sap: 'Off',
    meter_id: '10931298',
  },
];

/**
 * Data source for the VeeExceptionDetail view. This class should
 * encapsulate all logic for fetching and manipulating the displayed data
 * (including sorting, pagination, and filtering).
 */
export class AttribDetailDataSource extends DataSource<AttribDetailItem> {
  data: AttribDetailItem[] = EXAMPLE_DATA;
  paginator: MatPaginator;
  sort: MatSort;

  constructor() {
    super();
  }

  /**
   * Connect this data source to the table. The table will only update when
   * the returned stream emits new items.
   * @returns A stream of the items to be rendered.
   */
  connect(): Observable<AttribDetailItem[]> {
    // Combine everything that affects the rendered data into one update
    // stream for the data-table to consume.
    const dataMutations = [
      observableOf(this.data),
      this.paginator.page,
      this.sort.sortChange,
    ];

    return merge(...dataMutations).pipe(
      map(() => {
        return this.getPagedData(this.getSortedData([...this.data]));
      })
    );
  }

  /**
   *  Called when the table is being destroyed. Use this function, to clean up
   * any open connections or free any held resources that were set up during connect.
   */
  disconnect(): void {}

  /**
   * Paginate the data (client-side). If you're using server-side pagination,
   * this would be replaced by requesting the appropriate data from the server.
   */
  private getPagedData(data: AttribDetailItem[]): any {
    const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
    return data.splice(startIndex, this.paginator.pageSize);
  }

  /**
   * Sort the data (client-side). If you're using server-side sorting,
   * this would be replaced by requesting the appropriate data from the server.
   */
  private getSortedData(data: AttribDetailItem[]): any {
    if (!this.sort.active || this.sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      const isAsc = this.sort.direction === 'asc';
      switch (this.sort.active) {
        case 'name':
          return compare(+a.id, +b.id, isAsc);;
        case 'id':
          return compare(+a.id, +b.id, isAsc);
        default:
          return 0;
      }
    });
  }
}

/** Simple sort comparator for example ID/Name columns (for client-side sorting). */
function compare(a: string | number, b: string | number, isAsc: boolean): any {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
