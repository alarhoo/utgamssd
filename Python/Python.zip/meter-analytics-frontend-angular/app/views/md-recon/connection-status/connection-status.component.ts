import {
  Component,
  OnInit,
  ViewChild,
  AfterViewInit,
  Inject,
  Input,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material/table';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ChartComponent } from 'ng-apexcharts';
import { ChartOptions } from '../../shared/chartOptions';
import { RestApiService } from 'src/app/services/rest-api.service';

export interface ConnDetailItem {
  meterid: string;
  position: number;
  hesStatus: string;
  mdmStatus: string;
  sapStatus: string;
  ping: string;
}

const ELEMENT_DATA: ConnDetailItem[] = [
  {
    position: 1,
    meterid: '10931198',
    hesStatus: 'On',
    mdmStatus: 'On',
    sapStatus: 'Off',
    ping: '',
  },
  {
    position: 2,
    meterid: '10931197',
    hesStatus: 'Off',
    mdmStatus: 'Off',
    sapStatus: 'On',
    ping: '',
  },
  {
    position: 3,
    meterid: '10931199',
    hesStatus: 'On',
    mdmStatus: 'On',
    sapStatus: 'Off',
    ping: '',
  },
  {
    position: 4,
    meterid: '10931194',
    hesStatus: 'Off',
    mdmStatus: 'On',
    sapStatus: 'On',
    ping: '',
  },
  {
    position: 5,
    meterid: '10931193',
    hesStatus: 'Off',
    mdmStatus: 'Off',
    sapStatus: 'On',
    ping: '',
  },
  {
    position: 6,
    meterid: '10931192',
    hesStatus: 'On',
    mdmStatus: 'On',
    sapStatus: 'On',
    ping: '',
  },
  {
    position: 7,
    meterid: '10931191',
    hesStatus: 'On',
    mdmStatus: 'On',
    sapStatus: 'On',
    ping: '',
  },
  {
    position: 8,
    meterid: '10931148',
    hesStatus: 'On',
    mdmStatus: 'On',
    sapStatus: 'Off',
    ping: '',
  },
  {
    position: 9,
    meterid: '10931168',
    hesStatus: 'Off',
    mdmStatus: 'Off',
    sapStatus: 'On',
    ping: '',
  },
  {
    position: 10,
    meterid: '10931598',
    hesStatus: 'On',
    mdmStatus: 'Off',
    sapStatus: 'On',
    ping: '',
  },
];

@Component({
  selector: 'app-connection-status',
  templateUrl: './connection-status.component.html',
  styles: [''],
})
export class ConnectionStatusComponent implements OnInit, OnChanges {
  @ViewChild('chartForConnStatus') chartForConnStatus: ChartComponent;
  @Input() public selectedMeter;
  public chartOptions: Partial<ChartOptions>;
  showDetailConnectionTable = false;
  displayedColumns: string[] = [
    'select',
    'position',
    'meterid',
    'hesStatus',
    'mdmStatus',
    'sapStatus',
    'ping',
  ];
  dataSource = new MatTableDataSource<ConnDetailItem>(ELEMENT_DATA);
  selection = new SelectionModel<ConnDetailItem>(true, []);
  connectionName = 'Power';

  constructor(public dialog: MatDialog, private apiService: RestApiService) {
    // this.getDataForConnectionStatusChart();
  }

  ngOnInit(): void {}

  getDataForConnectionStatusChart(): void {
    this.chartOptions = {
      series: [
        {
          name: 'Matching',
          data: [],
        },
        {
          name: 'Mismatch',
          data: [],
        },
      ],
      chart: {
        type: 'bar',
        height: 200,
        stacked: true,
        // stackType: '100%',
        toolbar: {
          show: false,
        },
        events: {
          dataPointSelection: (event, chartContext, config) => {
            if (config.dataPointIndex === 0) {
              this.showDetailTableForConnection('Power');
            } else {
              this.showDetailTableForConnection('Load');
            }
          },
        },
      },
      plotOptions: {
        bar: {
          horizontal: true,
        },
      },
      dataLabels: {
        enabled: true,
      },
      xaxis: {
        categories: ['Power Status', 'Load Status'],
      },
      legend: {
        position: 'top',
        horizontalAlign: 'center',
      },
      theme: {
        mode: 'light',
        palette: 'palette2',
      },
      subtitle: {
        text: ``,
      },
      noData: {
        text: 'Loading...',
      },
    };

    this.apiService.getDataFromApi('apiForMasterDataSummary').subscribe({
      next: (response) => {
        const loadPowerItems = response.filter(
          (el) => el.METRICS_ID === 'LOAD_POWER_STATUS'
        );
        loadPowerItems.forEach((elem) => {
          if (
            elem.STATUS === 'MATCHING' &&
            elem.SUB_METRICS_ID === 'POWER_STATUS'
          ) {
            this.chartOptions.series[0].data[0] = elem.COUNT;
          } else if (
            elem.STATUS === 'MISMATCH' &&
            elem.SUB_METRICS_ID === 'POWER_STATUS'
          ) {
            this.chartOptions.series[1].data[0] = elem.COUNT;
          } else if (
            elem.STATUS === 'MATCHING' &&
            elem.SUB_METRICS_ID === 'LOAD_STATUS'
          ) {
            this.chartOptions.series[0].data[1] = elem.COUNT;
          } else {
            this.chartOptions.series[1].data[1] = elem.COUNT;
          }
        });
        setTimeout(() => {
          this.chartForConnStatus.toggleSeries('Matching');
          window.dispatchEvent(new Event('resize'));
        }, 1000);
      },
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    // console.log(
    //   'update',
    //   changes.selectedMeter,
    //   !changes.selectedMeter.currentValue
    // );
    if (changes.selectedMeter.currentValue) {
      this.chartOptions.series = [
        {
          name: 'Matching',
          data: [1, 0],
        },
        {
          name: 'Mismatch',
          data: [0, 1],
        },
      ];
    } else {
      this.getDataForConnectionStatusChart();
    }
  }
  /*
  showDetailTableForConnection(): void {
    this.showDetailConnectionTable = true;
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 1000);
  }

  closeColumn(): void {
    this.showDetailConnectionTable = false;
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 1000);
  }
  */

  showDetailTableForConnection(connectionName): void {
    this.dialog.open(ConnectionDetailDialogComponent, {
      maxWidth: '90vw',
      maxHeight: '90vh',
      height: '100%',
      width: '100%',
      data: {
        connectionName,
      },
    });
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 1000);
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected(): any {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle(): void {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.data.forEach((row) => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: ConnDetailItem): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.position + 1
    }`;
  }
}

// Dialog implementation
@Component({
  selector: 'app-connection-detail-dialog',
  templateUrl: 'connection-detail.dialog.html',
})
export class ConnectionDetailDialogComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatTable) table: MatTable<any>;

  ELEMENT_DATA: any[] = [];
  displayedColumns: string[] = [
    'select',
    // 'position',
    'METER_NUMBER',
    'HES_POWER_STATUS',
    'MDM_POWER_STATUS',
    'SAP_POWER_STATUS',
    'ping',
  ];

  dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);
  selection = new SelectionModel<any>(true, []);
  connectionName = 'Power';

  constructor(
    private apiService: RestApiService,
    @Inject(MAT_DIALOG_DATA) public data: { connectionName: string }
  ) {
    this.connectionName = data.connectionName;
  }

  ngOnInit(): void {
    this.getDataForDetailTable();
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }

  closeColumn(): void {
    // this.showDetailConnectionTable = false;
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 1000);
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected(): any {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle(): void {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.data.forEach((row) => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: any): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.METER_NUMBER
    }`;
  }

  getDataForDetailTable(): void {
    const apiName =
      this.connectionName === 'Power'
        ? 'apiForPowerStatusMismatch'
        : 'apiForLoadStatusMismatch';
    this.apiService.getDataFromApi(apiName).subscribe({
      next: (detailTable) => {
        this.dataSource.data = detailTable;
      },
    });
  }

  ping(): void {
    // console.log('ping');
    const status = ['Non-communicating', 'On & Open'];
    for (const item of this.selection.selected) {
      const selected = Math.random() > 0.5 ? 1 : 0;
      item.ping = status[selected];
      // console.log(status[selected]);
    }
    this.selection.clear();
  }

  pingHandler(): void {
    setTimeout(() => {
      this.ping();
    }, 1000);
  }
}
