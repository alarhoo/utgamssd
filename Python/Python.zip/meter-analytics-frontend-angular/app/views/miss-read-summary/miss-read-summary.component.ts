import { Component, OnInit } from '@angular/core';
import { RestApiService } from 'src/app/services/rest-api.service';

@Component({
  selector: 'app-miss-read-summary',
  templateUrl: './miss-read-summary.component.html',
  styles: [''],
})
export class MissReadSummaryComponent implements OnInit {
  // properties for KPI cards
  public readRatesThreshold = 98.5;
  public meterThreshold = 10000;
  public oKPIData: {
    icon: string;
    title: string;
    value: string;
    color: string;
    isNumber: boolean;
    tooltip: string;
    isPercent: boolean;
  }[] = [];

  constructor(private apiService: RestApiService) {}

  ngOnInit(): void {
    this.getDataForCards();
  }

  getDataForCards(): void {
    const meterResponse = this.apiService.getDataFromApi('apiForMeterCount');
    meterResponse.subscribe((d: any) => {
      this.oKPIData[0] = (
        {
          icon: 'supervised_user_circle',
          title: 'Total Customers',
          value: d[0].tot_customer_count,
          color:
            d[0].tot_customer_count < this.meterThreshold
              ? '#f44336'
              : '#ffb300',
          isNumber: true,
          tooltip: `Theshold value is ${this.meterThreshold}`,
          isPercent: false,
        }
      );
      
      this.oKPIData[1] = (  
        {
          icon: 'av_timer',
          title: 'Active Meters',
          value: d[0].active_meter_count,
          color:
            d[0].active_meter_count < this.meterThreshold
              ? '#f44336'
              : '#039be5',
          isNumber: true,
          tooltip: `Theshold value is ${this.meterThreshold}`,
          isPercent: false,
      });

      this.oKPIData[2] = (
        {
          icon: 'av_timer',
          title: 'Total Meters',
          value: d[0].tot_meter_count,
          color:
            d[0].tot_meter_count < this.meterThreshold ? '#f44336' : '#039be5',
          isNumber: true,
          tooltip: `Theshold value is ${this.meterThreshold}`,
          isPercent: false,
      });
      
    });
    const irResponse = this.apiService.getDataFromApi('apiForIRRate');
    irResponse.subscribe((d: any) => {
      this.oKPIData[3] = (
        {
          icon: 'rate_review',
          title: 'Register Read Rate',
          value: `${d[0].interval_register_date} %`,
          color:
            d[0].interval_register_date < this.readRatesThreshold
              ? '#f44336'
              : '#388e3c',
          isNumber: false,
          isPercent: true,
          tooltip: `Theshold value is ${this.readRatesThreshold}`,
        }
      );

      this.oKPIData[4] = (
        {
          icon: 'rate_review',
          title: 'Interval Read Rate',
          value: `${d[0].interval_read_date} %`,
          color:
            d[0].interval_read_date < this.readRatesThreshold
              ? '#f44336'
              : '#388e3c',
          isNumber: false,
          isPercent: true,
          tooltip: `Theshold value is ${this.readRatesThreshold}`,
      });
      
    });
  }
}
