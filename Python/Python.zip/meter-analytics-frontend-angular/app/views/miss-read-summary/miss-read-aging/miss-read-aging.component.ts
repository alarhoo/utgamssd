import { Component, OnInit, ViewChild } from '@angular/core';
import { RestApiService } from 'src/app/services/rest-api.service';
import { ChartOptions } from '../../shared/chartOptions';

@Component({
  selector: 'app-miss-read-aging',
  templateUrl: './miss-read-aging.component.html',
  styles: [''],
})
export class MissReadAgingComponent implements OnInit {
  // @ViewChild('chart') chart: ChartComponent | undefined;
  public agingChartOptions!: Partial<ChartOptions>;

  constructor(private apiService: RestApiService) {}

  ngOnInit(): void {
    this.getDataForAgingChart();
  }
  getDataForAgingChart(): void {
    this.agingChartOptions = {
      series: [
        {
          name: 'Missed Reads',
          data: [],
        },
      ],
      chart: {
        type: 'bar',
        height: 300,
        toolbar: {
          show: false,
        },
      },
      noData: {
        text: 'Loading...',
      },
      dataLabels: {
        enabled: true,
        offsetY: -20,
        style: {
          fontSize: '12px',
          colors: ['#304758'],
        },
      },
      xaxis: {
        categories: ['Days 1-3', 'Days 4-5', 'Days 6-7', 'Days 7-plus'],
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: '35%',
          dataLabels: {
            position: 'top',
          },
        },
      },
    };

    let seriesData = [];
    this.apiService.getDataFromApi('apiForMissReadAge').subscribe({
      next: (ageItems) => {
        seriesData = Object.values(ageItems[0]);
        this.agingChartOptions.series[0].data = seriesData;
        setTimeout(() => {
          window.dispatchEvent(new Event('resize'));
        }, 1000);
      },
    });
  }
}
