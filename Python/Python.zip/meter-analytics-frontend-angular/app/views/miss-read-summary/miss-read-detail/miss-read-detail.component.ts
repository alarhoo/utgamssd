import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { MatTableDataSource } from '@angular/material/table';
import { RestApiService } from 'src/app/services/rest-api.service';

@Component({
  selector: 'app-miss-read-detail',
  templateUrl: './miss-read-detail.component.html',
  styles: [''],
})
export class MissReadDetailComponent implements AfterViewInit, OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatTable) table: MatTable<any>;
  ELEMENT_DATA: any[] = [];
  displayedColumns: string[] = [
    'meterid',
    'bill-cycle',
    'last-read-date',
    'cust-class',
    'meter-type',
    // 'register-uom',
    'status',
    'aging-days',
    'service-order',
    'collection-time',
    'collection-node',
    'device-category',
    'firmware',
  ];

  dataSource = new MatTableDataSource<any>(this.ELEMENT_DATA);

  constructor(private apiService: RestApiService) {}

  ngOnInit(): void {
    this.getDataForDetailTable();
  }

  getDataForDetailTable(): void {
    this.apiService.getDataFromApi('apiForMissReadDetail').subscribe({
      next: (missReadDetail) => {
        this.dataSource.data = missReadDetail;
      },
    });
  }
  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }
}
