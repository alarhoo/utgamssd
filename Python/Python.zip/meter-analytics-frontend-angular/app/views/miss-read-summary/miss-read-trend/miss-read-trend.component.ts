import { Component, OnInit, ViewChild } from '@angular/core';
import dayjs from 'dayjs';
import { RestApiService } from 'src/app/services/rest-api.service';
import { ChartOptions } from '../../shared/chartOptions';

@Component({
  selector: 'app-miss-read-trend',
  templateUrl: './miss-read-trend.component.html',
  styles: [''],
})
export class MissReadTrendComponent implements OnInit {
  // @ViewChild('chart') chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;

  constructor(private apiService: RestApiService) {}

  ngOnInit(): void {
    this.getDataForTrendChart();
  }

  getDataForTrendChart(): void {
    this.chartOptions = {
      series: [],
      chart: {
        type: 'area',
        width: '100%',
        height: '300px',
        dropShadow: {
          enabled: true,
        },
        toolbar: {
          show: false,
        },
      },
      title: {
        text: '',
      },
      noData: {
        text: 'Loading...',
      },
      xaxis: {
        // type: 'datetime',
        // labels: {
        //   format: 'MM/dd/yyyy',
        // },
        labels: {
          formatter: (value) => {
            return dayjs(value).format('DD/MM/YYYY');
          },
        },
      },
      legend: {
        position: 'top',
        horizontalAlign: 'center',
      },
    };

    this.apiService.getDataFromApi('apiForMissReadTrend').subscribe({
      next: (trendItems) => {
        // sort the data by date
        trendItems.sort((a, b) => {
          return dayjs(a.INSERT_DATE) < dayjs(b.INSERT_DATE)
            ? -1
            : dayjs(a.INSERT_DATE) > dayjs(b.INSERT_DATE);
        });
        const series = [{ name: 'MISSED_READS', data: [] }];
        this.chartOptions.series = this.getChartData(
          trendItems,
          'datetime',
          'INSERT_DATE',
          series
        );
      },
    });
  }

  getChartData(data: any, type: string, xaxis: string, series: any): any {
    if (type === 'datetime') {
      const xCategory = [];
      data.forEach((elem: any) => {
        xCategory.push(elem[xaxis]);
        series.forEach((s, i) => {
          series[i].data.push({
            x: elem[xaxis],
            y: elem[series[i].name],
          });
        });
      });
      return series;
    }
  }
}
