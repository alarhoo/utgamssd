import {
  Component,
  OnInit,
  Input,
  SimpleChanges,
  OnChanges,
} from '@angular/core';
import { LoaderService } from 'src/app/services/loader.service';
import {
  ChartComponent,
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  ApexDataLabels,
  ApexStroke,
  ApexYAxis,
  ApexTitleSubtitle,
  ApexLegend,
  ApexTheme,
  ChartType,
} from 'ng-apexcharts';
import { series } from '../../vee-dashboard/vee-exception-trend/data';
export type ChartOptions = {
  series: ApexAxisChartSeries | ApexNonAxisChartSeries;
  chart: ApexChart;
  xaxis: ApexXAxis;
  stroke: ApexStroke;
  dataLabels: ApexDataLabels;
  yaxis: ApexYAxis;
  title: ApexTitleSubtitle;
  labels: string[];
  legend: ApexLegend;
  subtitle: ApexTitleSubtitle;
  noData: ApexNoData;
  plotOptions: ApexPlotOptions;
  theme: ApexTheme;
  colors: string[];
  grid: ApexGrid;
};

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss'],
})
export class CardComponent implements OnInit, OnChanges {
  public chartOptions: Partial<ChartOptions>;

  @Input() cardTitle: string;
  @Input() chartType: ChartType;
  @Input() chartCategory: Array<any>;

  // @Input() chart: ApexChart;
  // @Input() annotations: ApexAnnotations;
  // @Input() colors: string[];
  // @Input() dataLabels: ApexDataLabels;
  @Input() series: ApexAxisChartSeries | ApexNonAxisChartSeries;
  // @Input() chartSeries: ApexAxisChartSeries | ApexNonAxisChartSeries;
  // @Input() stroke: ApexStroke;
  // @Input() labels: string[];
  // @Input() legend: ApexLegend;
  // @Input() fill: ApexFill;
  // @Input() tooltip: ApexTooltip;
  // @Input() plotOptions: ApexPlotOptions;
  // @Input() responsive: ApexResponsive[];
  @Input() xaxis: ApexXAxis;
  // @Input() yaxis: ApexYAxis | ApexYAxis[];
  // @Input() grid: ApexGrid;
  // @Input() states: ApexStates;
  // @Input() title: ApexTitleSubtitle;
  // @Input() subtitle: ApexTitleSubtitle;
  // @Input() theme: ApexTheme;
  // @Input() noData: ApexNoData;

  constructor(public loaderService: LoaderService) {}

  ngOnInit(): void {
    // this.initChart();

    console.log(this.series);
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes);
    if (changes.series.currentValue && changes.xaxis.currentValue) {
      this.initChart();
      console.log(this.chartCategory);

      // this.chartOptions.xaxis.categories = this.chartCategory;
    }
  }

  initChart(): void {
    this.chartOptions = {
      series: [
        {
          name: 'basic',
          data: [105, 234, 35, 105, 234, 35, 98],
        },
      ],
      chart: {
        type: 'bar',
        height: 350,
      },
      xaxis: {
        categories: [], // this.chartCategory
      },
    };
  }
}
