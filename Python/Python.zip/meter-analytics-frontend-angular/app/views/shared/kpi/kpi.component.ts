import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-kpi',
  templateUrl: './kpi.component.html',
  styleUrls: ['./kpi.component.scss'],
})
export class KpiComponent implements OnInit {
  @Input()
  icon!: string;
  @Input()
  title!: string;
  @Input()
  value!: string;
  @Input()
  color!: string;
  @Input()
  isNumber!: boolean;
  @Input()
  isPercent!: boolean;

  constructor() {}

  ngOnInit(): void {}
}
