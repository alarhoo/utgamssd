import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { DecimalPipe, TitleCasePipe } from '@angular/common';
import { MAT_DATE_LOCALE } from '@angular/material/core';

import { AppRoutingModule, routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularMaterialModule } from './angular-material/angular-material.module';
import {
  HttpClient,
  HttpClientModule,
  HTTP_INTERCEPTORS,
} from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AngularSplitModule } from 'angular-split';
import { NgApexchartsModule } from 'ng-apexcharts';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { MatTableExporterModule } from 'mat-table-exporter';

// Map view
import { AgmCoreModule } from '@agm/core';

// Services
import { InterceptorService } from './services/interceptor.service';
import { LoaderService } from './services/loader.service';
import { DetectionComparisonComponent } from './views/revenue-protection-report/detection-comparison/detection-comparison.component';
import { DispositionResultComponent } from './views/revenue-protection-report/disposition-result/disposition-result.component';
import { SuspectListDetailsComponent } from './views/revenue-protection-report/suspect-list-details/suspect-list-details.component';

// AoT requires an exported function for factories
export function HttpLoaderFactory(http: HttpClient): any {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    DetectionComparisonComponent,
    DispositionResultComponent,
    SuspectListDetailsComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    AngularMaterialModule,
    HttpClientModule,
    FlexLayoutModule,
    AngularSplitModule,
    NgApexchartsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
    MatTableExporterModule,
    AgmCoreModule.forRoot({
      // please get your own API key here:
      // https://developers.google.com/maps/documentation/javascript/get-api-key?hl=en
      apiKey: 'AIzaSyBVY99T0Cj5z2UOEZftcfpgyKit9Bxm_eQ',
      libraries: ['visualization'],
    }),
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true,
    },
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
    LoaderService,
    InterceptorService,
    DecimalPipe,
    TitleCasePipe,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
