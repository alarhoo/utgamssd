import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {
  LayoutComponent,
  FeedbackDialogComponent,
  SettingsDialogComponent,
} from './views/layout/layout.component';
import { LoginComponent } from './views/login/login.component';

import { MissReadSummaryComponent } from './views/miss-read-summary/miss-read-summary.component';
import { MissReadTrendComponent } from './views/miss-read-summary/miss-read-trend/miss-read-trend.component';
import { MissReadAgingComponent } from './views/miss-read-summary/miss-read-aging/miss-read-aging.component';
import { MissReadDetailComponent } from './views/miss-read-summary/miss-read-detail/miss-read-detail.component';

import { MdReconComponent } from './views/md-recon/md-recon.component';
import {
  MdReconSummaryComponent,
  MdReconDetailDialogComponent,
} from './views/md-recon/md-recon-summary/md-recon-summary.component';
import {
  AttrChartsComponent,
  AttribDetailDialogComponent,
} from './views/md-recon/attr-charts/attr-charts.component';
import {
  ConnectionStatusComponent,
  ConnectionDetailDialogComponent,
} from './views/md-recon/connection-status/connection-status.component';

import { OptOutReportComponent } from './views/opt-out-report/opt-out-report.component';
import { OptOutAgingComponent } from './views/opt-out-report/opt-out-aging/opt-out-aging.component';
import { OptOutTrendComponent } from './views/opt-out-report/opt-out-trend/opt-out-trend.component';
import { OptOutDetailComponent } from './views/opt-out-report/opt-out-detail/opt-out-detail.component';

import { VeeDashboardComponent } from './views/vee-dashboard/vee-dashboard.component';
import { VeeExceptionTrendComponent } from './views/vee-dashboard/vee-exception-trend/vee-exception-trend.component';
import { VeeExceptionDetailComponent } from './views/vee-dashboard/vee-exception-detail/vee-exception-detail.component';
import { VeeExceptionRankComponent } from './views/vee-dashboard/vee-exception-rank/vee-exception-rank.component';

import { MapViewComponent } from './views/map-view/map-view.component';

import { RevenueProtectionReportComponent } from './views/revenue-protection-report/revenue-protection-report.component';
import { SuspectListDetailComponent } from './views/revenue-protection-report/suspect-list-detail/suspect-list-detail.component';
import { PremiseHistoryDetailComponent } from './views/revenue-protection-report/premise-history-detail/premise-history-detail.component';

import { PageNotFoundComponent } from './views/page-not-found/page-not-found.component';
import { CardComponent } from './views/shared/card/card.component';
import { TableComponent } from './views/shared/table/table.component';
import { KpiComponent } from './views/shared/kpi/kpi.component';
import { BadgeComponent } from './views/shared/badge/badge.component';

const routes: Routes = [
  // { path: '', redirectTo: 'Login', pathMatch: 'full' },
  // { path: 'Login', component: LoginComponent },
  {
    path: '',
    component: LayoutComponent,
    children: [
      { path: '', redirectTo: 'MeterReadSummary', pathMatch: 'full' },
      { path: 'MeterReadSummary', component: MissReadSummaryComponent },
      { path: 'MDRecon', component: MdReconComponent },
      { path: 'OptOutReport', component: OptOutReportComponent },
      { path: 'VEEDashboard', component: VeeDashboardComponent },
      { path: 'MapView', component: MapViewComponent },
      { path: 'RevenueProtection', component: RevenueProtectionReportComponent },
      { path: '**', component: PageNotFoundComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
export const routingComponents = [
  LayoutComponent,
  FeedbackDialogComponent,
  SettingsDialogComponent,
  LoginComponent,
  MissReadSummaryComponent,
  MissReadTrendComponent,
  MissReadAgingComponent,
  MissReadDetailComponent,
  MdReconComponent,
  MdReconSummaryComponent,
  MdReconDetailDialogComponent,
  AttrChartsComponent,
  AttribDetailDialogComponent,
  ConnectionStatusComponent,
  ConnectionDetailDialogComponent,
  OptOutReportComponent,
  OptOutAgingComponent,
  OptOutTrendComponent,
  OptOutDetailComponent,
  VeeDashboardComponent,
  VeeExceptionTrendComponent,
  VeeExceptionDetailComponent,
  VeeExceptionRankComponent,
  MapViewComponent,
  RevenueProtectionReportComponent,
  SuspectListDetailComponent,
  PremiseHistoryDetailComponent,
  PageNotFoundComponent,
  CardComponent,
  TableComponent,
  KpiComponent,
  BadgeComponent,
];
